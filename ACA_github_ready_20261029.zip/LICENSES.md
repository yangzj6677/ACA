# License scope and attribution

The project-owned original Python code in `reproduce/` and `maintainer_scripts/`
is offered under the [MIT License](LICENSE). This does not grant rights in
external models, recordings, third-party source code or datasets.

The authors have selected **CC BY-NC-SA 4.0** for their derived research
data, including the fixed recipes and validation-result JSON files, subject to
review of source rights and the applicability of the chosen terms before
public release. The license requires attribution, noncommercial use, and
sharing adaptations under the same license; see its
[legal code](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.en).
Project protocols are research documentation and remain subject to the same
pre-publication scope review. README files, citations and dependency lists do
not change the licenses of any linked or referenced third-party assets.

The source recordings are DCASE 2024/2025 Challenge Task 2 datasets created
by Nishida and colleagues. The official records list creators and license terms:
[2024 additional training](https://zenodo.org/records/11259435),
[2024 evaluation](https://zenodo.org/records/11363076),
[2025 additional training](https://zenodo.org/records/15392814), and
[2025 evaluation](https://zenodo.org/records/15519362). Our recipes describe
subsets, recording identifiers, perturbation choices and derived scores; they
do not include the original audio. The four linked records state CC BY-NC-SA
4.0. Individual assets and third-party rights must still be checked before
publishing the candidate.
