"""Exercise batch accounting and validation-state transitions without audio/GPU."""
import contextlib
import hashlib
import importlib.util
import io
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1] / 'reproduce'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


class BatchModeTest(unittest.TestCase):
    def exercise(self, beats, reuse, expected):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            runner = 'run_all_beats.py' if beats else 'run_all.py'
            main_script = 'run_beats.py' if beats else 'run_echo.py'
            recipes_dir = 'beats_recipes' if beats else 'recipes'
            encodings, scores = (3600, 7200) if beats else (3300, 14400)
            for name in (runner, 'run_echo.py', 'recovery_core.py', 'run_beats.py'):
                (root / name).write_bytes((ROOT / name).read_bytes())
            (root / recipes_dir).mkdir()
            pilot = ('2025', 'BandSealer') if beats else ('2024', '3DPrinter')
            cases = [pilot] + [('2024', f'Other{i:02}') for i in range(16)]
            for year, machine in cases:
                (root / recipes_dir / f'{year}_{machine}.json').write_text(json.dumps(dict(year=year, machine=machine)))

            def make_result(dest, recipe, verified):
                dest.mkdir(parents=True, exist_ok=True)
                info = dict(state='passed', recipe_SHA256=sha(recipe), script_SHA256=sha(root / main_script),
                            core_SHA256=sha(root / 'recovery_core.py'), audio_encodings=encodings,
                            score_rows=scores, outputs={}, comparison={'scores': {'p_alarm_exact': True}} if verified else {})
                if beats:
                    info['shared_decode_setup_script_SHA256'] = sha(root / 'run_echo.py')
                (dest / 'complete.json').write_text(json.dumps(info))

            class FakePopen:
                pid = 12345
                def __init__(self, command, cwd):
                    self.command = command
                    args = {command[i]: command[i + 1] for i in range(2, len(command), 2)}
                    make_result(Path(args['--output']), Path(args['--recipe']), '--expected' in args)
                def wait(self):
                    return 0

            argv = [runner, '--data-root', str(root/'data'), '--vendor', str(root/'vendor'),
                    '--checkpoint', str(root/'model'), '--output', str(root/'output')]
            if expected:
                argv += ['--expected-root', str(root/'reference')]
            if reuse:
                pilot_dir = root / 'pilot'
                make_result(pilot_dir, root/recipes_dir/f'{pilot[0]}_{pilot[1]}.json', True)
                argv += ['--reuse-pilot', str(pilot_dir)]
            stub = types.ModuleType('run_echo')
            stub.sha, stub.read = sha, read
            spec = importlib.util.spec_from_file_location('batch_under_test', root/runner)
            module = importlib.util.module_from_spec(spec)
            with patch.dict(sys.modules, {'run_echo': stub}):
                spec.loader.exec_module(module)
                with patch.object(sys, 'argv', argv), patch.object(module.subprocess, 'Popen', FakePopen), contextlib.redirect_stdout(io.StringIO()):
                    module.main()
            result = read(root/'output'/'complete.json')
            self.assertEqual(result['main_audio_encodings'], 17 * encodings)
            self.assertEqual(result['reused_pilot_encodings'], encodings if reuse else 0)
            self.assertEqual(result['new_encodings_this_batch'], (16 if reuse else 17) * encodings)
            self.assertEqual(sum(c['reused'] for c in result['cases']), int(reuse))
            self.assertEqual(all(c['reference_comparison'] for c in result['cases']), expected)
            self.assertEqual(result['state'].endswith('_verified'), expected)

    def test_all_mode_combinations(self):
        for beats in (False, True):
            for reuse in (False, True):
                for expected in (False, True):
                    with self.subTest(beats=beats, reuse=reuse, expected=expected):
                        self.exercise(beats, reuse, expected)


if __name__ == '__main__':
    unittest.main()
