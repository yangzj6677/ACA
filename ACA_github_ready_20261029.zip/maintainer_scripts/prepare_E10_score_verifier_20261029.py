"""Derive the E10 input adapter for the existing independent arithmetic checker."""
from pathlib import Path
HERE=Path(__file__).resolve().parent
source=(HERE/'verify_factorial_scores_E9_20261028.py').read_text()
source=source.replace('E9','E10').replace('E10_factorial_reference_scale_20261028','E10_active_window_20261029')
old="    checks=[];total=0;maxerr=0.;started=time.time()"
new="    feature_seal=read(OUT/'features_seal.json')\n    for name,h in feature_seal['outputs'].items():assert sha(OUT/name)==h\n"+old
assert old in source;source=source.replace(old,new)
old="            mixed=np.load(source/'features.npz')['projected'];maps=np.load(prior/'maps.npz')"
new=old+"\n            fresh=np.load(OUT/encoder/year/machine/'features.npz')['projected']"
assert old in source;source=source.replace(old,new)
old="                    f=mixed if encoder=='BEATs' else mixed[vi];o=original if encoder=='BEATs' else original[vi];bands=f.shape[-2]"
new="                    legacy=mixed if encoder=='BEATs' else mixed[vi];new=fresh if encoder=='BEATs' else fresh[vi]\n                    f=np.concatenate([legacy[0:1,60:],new]);o=original if encoder=='BEATs' else original[vi];bands=f.shape[-2]"
assert old in source;source=source.replace(old,new).replace('f[:,100:]','f[:,40:]')
dest=HERE/'verify_active_window_scores_E10_20261029.py';assert not dest.exists();dest.write_text(source)
print('E10 independent arithmetic checker prepared with explicit feature-input adaptation')
