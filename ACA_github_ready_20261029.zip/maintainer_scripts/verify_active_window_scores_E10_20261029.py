"""Independent normalized-matrix-product score and p replay for every E10 row."""
import csv,hashlib,json,sys,time
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parents[2];BASE=ROOT/'experiments/results/condition_adaptation/evidence_mechanism_20261022';OUT=BASE/'E10_active_window_20261029';PRIOR=ROOT/'submission/portable_sensitivity_full_20261028'
CELLS=['M_M','O_O','O_M','M_O','M_unit','O_unit']
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def normalize(x):
    x=x.astype(np.float64);length=np.sqrt(np.sum(x*x,axis=-1,keepdims=True));assert np.isfinite(x).all() and (length>0).all();return x/length
def distance(x,y):return np.clip(1.-x@y.T,0,2)/2
def independently_transform(x,w):return np.stack([(x[...,b,:].astype(float)@w[b].astype(float)).astype(np.float32) for b in range(x.shape[-2])],axis=-2)
def main():
    seal=read(OUT/'score_seal.json');assert seal['state']=='all_E10_scores_sealed_before_label_evaluation'
    for n,h in seal['outputs'].items():assert sha(OUT/n)==h
    feature_seal=read(OUT/'features_seal.json')
    for name,h in feature_seal['outputs'].items():assert sha(OUT/name)==h
    checks=[];total=0;maxerr=0.;started=time.time()
    with threadpool_limits(limits=2):
        for c in read(PRIOR/'plan.json')['cases']:
            encoder,year,machine=[c[k] for k in ['encoder','year','machine']];source=Path(c['features']);recipe=read(Path(c['recipe']));prior=PRIOR/'scores'/encoder/year/machine
            mixed=np.load(source/'features.npz')['projected'];maps=np.load(prior/'maps.npz')
            fresh=np.load(OUT/encoder/year/machine/'features.npz')['projected']
            if encoder=='BEATs':original=np.load(source/'original_projected.npy');lookup={i:i for i in range(1200)};views=['BEATs']
            else:
                loaded=np.load(source/'original_features.npz');original=loaded['projected'];lookup={int(i):j for j,i in enumerate(loaded['ids'])};views=['CLS','FM']
            err=0.;case_count=0;scorefile=OUT/encoder/year/machine/'scores.csv'
            with scorefile.open(encoding='utf-8',newline='') as file:
                reader=csv.DictReader(file)
                for vi,view in enumerate(views):
                    legacy=mixed if encoder=='BEATs' else mixed[vi];new=fresh if encoder=='BEATs' else fresh[vi]
                    f=np.concatenate([legacy[0:1,60:],new]);o=original if encoder=='BEATs' else original[vi];bands=f.shape[-2]
                    ref=o[[lookup[i] for i in recipe['reference_ids']]];cal=o[[lookup[i] for i in recipe['calibration_ids']]]
                    for offset in [0,1,7,13,29,43]:
                        w=maps[view+'_shift'+str(offset)];mapped=independently_transform(ref,w);query=independently_transform(np.concatenate([f[:,40:].reshape(-1,bands,128),cal]),w)
                        values={cell:np.zeros(1900) for cell in CELLS}
                        for b in range(bands):
                            mm=normalize(mapped[:,b]);oo=normalize(ref[:,b]);qq=normalize(query[:,b]);dist_m=distance(qq,mm);dist_o=distance(qq,oo)
                            scales=[]
                            for bank in [mm,oo]:
                                within=distance(bank,bank);np.fill_diagonal(within,np.inf);scales.append(np.maximum(within.min(1),1e-6).astype(np.float32))
                            rm,ro=scales
                            for cell,dist,rho in [('M_M',dist_m,rm),('O_O',dist_o,ro),('O_M',dist_o,rm),('M_O',dist_m,ro),('M_unit',dist_m,None),('O_unit',dist_o,None)]:values[cell]+=(dist if rho is None else dist/rho.astype(float)[None,:]).min(1)/bands
                        for cell,value in values.items():
                            # Direct comparison counting, rather than production's searchsorted implementation.
                            pv=(1+(value[1800:,None]>=value[None,:1800]).sum(0))/101
                            for j,item in enumerate(recipe['records'][100:]*9):
                                r=next(reader);assert (r['view'],int(r['offset']),r['interface'],int(r['condition']),r['filename'])==(view,offset,cell,j//200,item['filename'])
                                old=float(r['score']);e=abs(float(value[j])-old);assert e<=1e-7+1e-6*abs(old),(c,cell,j,e)
                                assert pv[j]==float(r['p_value']) and str(bool(pv[j]<=.04))==r['alarm'],(c,cell,j)
                                err=max(err,e);case_count+=1
                assert next(reader,None) is None
            total+=case_count;maxerr=max(maxerr,err);checks.append(dict(encoder=encoder,year=year,machine=machine,score_rows=case_count,max_absolute_error=err,p_alarm_exact=True))
            print('E10 independent score check',encoder,year,machine,'passed',flush=True)
    assert total==3304800
    result=dict(state='passed_all_E10_scores_independent_arithmetic',score_rows=total,max_absolute_score_error=maxerr,all_p_values_and_alarms_exact=True,formula='float64 normalization and matrix multiplication; independently computed reference nearest-neighbor scales and direct calibration comparison counts',checks=checks,seconds=time.time()-started,score_seal_SHA256=sha(OUT/'score_seal.json'),verifier_SHA256=sha(Path(__file__)))
    (OUT/'independent_score_validation.json').write_text(json.dumps(result,indent=2)+'\n');print('E10 independent arithmetic verified all scores',flush=True)
if __name__=='__main__':main()
