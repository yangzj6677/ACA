"""Freeze active-centered waveforms, then encode all cases without labels or fits."""
import hashlib,json,sys,time,os,io,gc
from pathlib import Path
import numpy as np
from scipy.io import wavfile
ROOT=Path(__file__).resolve().parents[2];PORT=ROOT/'submission/audio_repro_20261028';sys.path.insert(0,str(PORT))
from run_echo import setup
from recovery_core import project
BASE=ROOT/'experiments/results/condition_adaptation/evidence_mechanism_20261022';OUT=BASE/'E10_active_window_20261029'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def digest(a):return hashlib.sha256(a.tobytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def native(p):
    sr,a=wavfile.read(io.BytesIO(p.read_bytes()));assert sr==16000 and a.ndim==1
    if a.dtype.kind=='i':a=(a.astype(np.float32)/float(2**(np.iinfo(a.dtype).bits-1))).astype(np.float32)
    else:assert a.dtype.kind=='f';a=a.astype(np.float32)
    assert np.isfinite(a).all();return a
def basewave(p):
    a=native(p);n=min(len(a),160000);return np.pad(a[:160000],(0,max(0,160000-len(a)))),n
def wave(base,noise,v):
    start,end=v['start'],v['end'];n=end-start;ramp=min(1600,n//2);envelope=np.ones(n,np.float32)
    edge=(.5-.5*np.cos(np.linspace(0,np.pi,ramp))).astype(np.float32);envelope[:ramp]=edge;envelope[-ramp:]=edge[::-1]
    addition=(noise[:n]*envelope).astype(np.float32);a=base.copy();a[start:end]=(base[start:end]+(addition*v['beta']).astype(np.float32)).astype(np.float32)
    assert np.array_equal(a[:start],base[:start]) and np.array_equal(a[end:],base[end:]);return a
def prepare():
    assert not OUT.exists();OUT.mkdir();cases=[];pins={};noise={}
    for p in [Path(__file__),ROOT/'experiments/有效录音内加噪E10协议_2026-10-29.md',PORT/'run_echo.py',PORT/'recovery_core.py']:pins[str(p.relative_to(ROOT))]=sha(p)
    for p in sorted((PORT/'recipes').glob('*.json')):
        r=read(p);records=[]
        for item in r['records'][60:]:
            base,valid=basewave(ROOT/item['path']);assert digest(base)==item['conditions'][0]['waveform_SHA256']
            n=min(96000,valid);start=(valid-n)//2;ramp=min(1600,n//2);envelope=np.ones(n,np.float32);edge=(.5-.5*np.cos(np.linspace(0,np.pi,ramp))).astype(np.float32);envelope[:ramp]=edge;envelope[-ramp:]=edge[::-1];variants=[]
            for ci,old in enumerate(item['conditions'][1:]):
                path=old['noise_path']
                if path not in noise:noise[path]=native(ROOT/path)
                z=(noise[path][:n]*envelope).astype(np.float32);db=-10 if ci%2==0 else 0
                beta=float(np.sqrt(np.mean(base[start:start+n].astype(float)**2))/np.sqrt(np.mean(z.astype(float)**2))*10**(db/20))
                v=dict(noise_path=path,start=start,end=start+n,incremental_dB=db,beta=beta);new=wave(base,noise[path],v);assert np.array_equal(new[valid:],base[valid:]);v['waveform_SHA256']=digest(new);variants.append(v)
            records.append(dict(id=item['id'],path=item['path'],valid_samples=valid,conditions=variants))
        recipe=OUT/(r['year']+'_'+r['machine']+'_waves.json');save(recipe,dict(year=r['year'],machine=r['machine'],records=records));cases.append(dict(year=r['year'],machine=r['machine'],waves=recipe.name,wave_recipe_SHA256=sha(recipe)))
        for name,h in r['audio_inputs'].items():assert sha(ROOT/name)==h;pins[name]=h
        print('E10 waveforms fixed',r['year'],r['machine'],flush=True)
    save(OUT/'plan_seal.json',dict(state='all_17_waveform_recipes_fixed_before_encoding',cases=cases,inputs=pins,planned_new_audio_encodings=65280,historical_data_exposed=True,new_independent_cohort=False))
def encode():
    import torch
    from safetensors.torch import load_file
    from threadpoolctl import threadpool_limits
    plan=read(OUT/'plan_seal.json');assert not (OUT/'features_seal.json').exists()
    for n,h in plan['inputs'].items():assert sha(ROOT/n)==h
    for c in plan['cases']:assert sha(OUT/c['waves'])==c['wave_recipe_SHA256']
    setup();started=time.time();outputs={};total=0
    for encoder in ['BEATs','ECHOv2']:
        vendor=ROOT/('experiments/vendor/GenRepASD' if encoder=='BEATs' else 'experiments/vendor/ECHOv2_b2fb585')
        checkpoint=ROOT/('experiments/models/BEATs_iter3.pt' if encoder=='BEATs' else 'experiments/models/ECHOv2_234c2cc250225a1915f8bad964bb6f3aa7d5109f/model.safetensors')
        for c in plan['cases']:
            r=read(PORT/('beats_recipes' if encoder=='BEATs' else 'recipes')/(c['year']+'_'+c['machine']+'.json'));assert sha(checkpoint)==r['checkpoint_SHA256']
            for name,h in r['vendor_files'].items():assert sha(vendor/name)==h
        sys.path.insert(0,str(vendor))
        if encoder=='BEATs':
            from beats.BEATs import BEATs,BEATsConfig
            ck=torch.load(checkpoint,map_location='cpu',weights_only=True);model=BEATs(BEATsConfig(ck['cfg']));model.load_state_dict(ck['model'],strict=True);del ck
        else:
            from src.audioMAE_band_upgrade import AudioMAEWithBand
            from src.utils import sanitize_state_dict
            model=AudioMAEWithBand();model.load_state_dict(sanitize_state_dict(load_file(str(checkpoint))),strict=True)
        model=model.eval().requires_grad_(False).cuda()
        for c in plan['cases']:
            dest=OUT/encoder/c['year']/c['machine'];dest.mkdir(parents=True,exist_ok=False);rr=read(OUT/c['waves'])['records'];raw=np.empty((8,240,8,768),np.float32) if encoder=='BEATs' else np.empty((2,8,240,7,384),np.float32);cache={}
            for j,item in enumerate(rr):
                if time.time()-started>7200:raise TimeoutError('E10 declared encoding timeout')
                base,valid=basewave(ROOT/item['path']);assert valid==item['valid_samples'];waves=[]
                for v in item['conditions']:
                    if v['noise_path'] not in cache:cache[v['noise_path']]=native(ROOT/v['noise_path'])
                    a=wave(base,cache[v['noise_path']],v);assert digest(a)==v['waveform_SHA256'];waves.append(a)
                if encoder=='BEATs':
                    q=torch.tensor(np.stack(waves),device='cuda')
                    with torch.autocast('cuda',dtype=torch.bfloat16):_,_,layers=model.extract_features(q,layer=11,need_weights=False)
                    raw[:,j]=layers[-1][0].transpose(0,1).reshape(8,62,8,768).mean(1).float().cpu().numpy()
                else:
                    for ci,a in enumerate(waves):
                        cls,frames=model.extract_features_from_audio(torch.from_numpy(a).unsqueeze(0),16000);raw[:,ci,j]=np.stack([cls.numpy().reshape(7,384),frames.mean(0).numpy().reshape(7,384)])
                if (j+1)%20==0:
                    save(OUT/'status.json',dict(stage='encoding',pid=os.getpid(),encoder=encoder,year=c['year'],machine=c['machine'],records=j+1,total_new_encodings=total+(j+1)*8));print('E10',encoder,c['year'],c['machine'],j+1,'/240',flush=True)
            assert np.isfinite(raw).all()
            with threadpool_limits(limits=2):projected,_=project(raw,768 if encoder=='BEATs' else 384,8 if encoder=='BEATs' else 7)
            np.savez(dest/'features.npz',raw_pooled=raw,projected=projected,ids=np.array([r['id'] for r in rr]));total+=1920
            save(dest/'complete.json',dict(state='encoded_without_labels',new_audio_encodings=1920,wave_recipe_SHA256=c['wave_recipe_SHA256'],features_SHA256=sha(dest/'features.npz'),checkpoint_SHA256=sha(checkpoint)))
            outputs[str((dest/'features.npz').relative_to(OUT))]=sha(dest/'features.npz')
        del model,raw;gc.collect();torch.cuda.empty_cache()
    assert total==65280;save(OUT/'features_seal.json',dict(state='all_new_features_sealed_before_scoring',new_audio_encodings=total,outputs=outputs,plan_seal_SHA256=sha(OUT/'plan_seal.json')))
    save(OUT/'status.json',dict(stage='features_sealed',new_audio_encodings=total));print('E10 all new features sealed',flush=True)
if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='encode':encode()
    else:raise ValueError('Use prepare or encode')
