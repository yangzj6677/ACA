"""E9 label-free factorial reference/scale and plain-cosine score production."""
import csv,hashlib,json,os,sys,time
from pathlib import Path
import numpy as np
from scipy.spatial.distance import cdist
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parents[2];S=ROOT/'submission';PORT=S/'audio_repro_20261028'
sys.path.insert(0,str(PORT))
from recovery_core import transform,prepare_bank,calibrated_p
BASE=ROOT/'experiments/results/condition_adaptation/evidence_mechanism_20261022'
OUT=BASE/'E9_factorial_reference_scale_20261028';PRIOR=S/'portable_sensitivity_full_20261028'
PROTOCOL=ROOT/'experiments/参考坐标与局部尺度分离E9协议_2026-10-28.md'
CELLS=['M_M','O_O','O_M','M_O','M_unit','O_unit'];OFFSETS=[0,1,7,13,29,43]
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:yield from csv.DictReader(f)
def main():
    assert not OUT.exists(),'Preserve all prior output.'
    cases=read(PRIOR/'plan.json')['cases'];assert len(cases)==34
    validation=read(S/'full_portable_sensitivity_validation_20261028.json');assert validation['state']=='passed_all_34_encoder_cases'
    inputs={};datasets=[]
    for p in [PROTOCOL,Path(__file__),PORT/'recovery_core.py',PRIOR/'plan.json',PRIOR/'complete.json',PRIOR/'score_seal.json',S/'full_portable_sensitivity_validation_20261028.json']:inputs[str(p.relative_to(ROOT))]=sha(p)
    for c in cases:
        encoder,year,machine=[c[k] for k in ['encoder','year','machine']];features=Path(c['features']);old=PRIOR/'scores'/encoder/year/machine;done=read(old/'complete.json')
        assert sha(features/'complete.json')==c['source_complete_SHA256']
        for n,h in done['input_SHA256'].items():assert sha(features/n)==h;inputs[str((features/n).relative_to(ROOT))]=h
        for n in ['maps.npz','scores.csv','normal_angles.csv']:assert sha(old/n)==done['outputs'][n];inputs[str((old/n).relative_to(ROOT))]=sha(old/n)
        assert sha(Path(c['recipe']))==done['recipe_SHA256'];inputs[str(Path(c['recipe']).relative_to(ROOT))]=done['recipe_SHA256']
        datasets.append(c)
    OUT.mkdir();save('plan_seal.json',dict(state='fixed_before_E9_scoring',cells=CELLS,offsets=OFFSETS,inputs=inputs,new_encodings=0,new_fits=0,post_hoc=True,historical_labels_exposed=True))
    started=time.time();outputs={};anchors=[];total=0
    save('status.json',dict(stage='running',pid=os.getpid(),cases_complete=0,started_unix=started,hard_timeout_seconds=1800))
    with threadpool_limits(limits=2):
        for ci,c in enumerate(datasets):
            if time.time()-started>1800:raise TimeoutError('Declared E9 hard timeout exceeded')
            encoder,year,machine=[c[k] for k in ['encoder','year','machine']];features=Path(c['features']);old=PRIOR/'scores'/encoder/year/machine;recipe=read(Path(c['recipe']))
            mixed=np.load(features/'features.npz')['projected'];maps=np.load(old/'maps.npz')
            if encoder=='BEATs':original=np.load(features/'original_projected.npy');lookup={i:i for i in range(1200)};views=['BEATs']
            else:
                loaded=np.load(features/'original_features.npz');original=loaded['projected'];lookup={int(v):i for i,v in enumerate(loaded['ids'])};views=['CLS','FM']
            expected={(r['view'],int(r['offset']),r['interface'],int(r['condition']),r['filename']):(float(r['score']),float(r['p_value']),r['alarm']) for r in rows(old/'scores.csv')}
            dest=OUT/encoder/year/machine;dest.mkdir(parents=True);filename=dest/'scores.csv';case_count=0;max_anchor=0.
            with filename.open('x',encoding='utf-8',newline='') as file:
                writer=csv.DictWriter(file,fieldnames=['encoder','view','year','machine','offset','interface','condition','filename','score','p_value','alarm']);writer.writeheader()
                for vi,view in enumerate(views):
                    f=mixed if encoder=='BEATs' else mixed[vi];o=original if encoder=='BEATs' else original[vi];bands=f.shape[-2]
                    np.testing.assert_array_equal(f[0],o[[lookup[r['id']] for r in recipe['records']]])
                    ref=o[[lookup[i] for i in recipe['reference_ids']]];cal=o[[lookup[i] for i in recipe['calibration_ids']]];ob=prepare_bank(ref)
                    for offset in OFFSETS:
                        w=maps[view+'_shift'+str(offset)];mb=prepare_bank(transform(ref,w));query=transform(np.concatenate([f[:,100:].reshape(-1,bands,128),cal]),w)
                        values={cell:np.zeros(1900,dtype=np.float64) for cell in CELLS}
                        for b in range(bands):
                            dm=np.clip(cdist(query[:,b].astype(float),mb.vectors[:,b].astype(float),'cosine'),0,2)/2
                            do=np.clip(cdist(query[:,b].astype(float),ob.vectors[:,b].astype(float),'cosine'),0,2)/2
                            for cell,dist,rho in [('M_M',dm,mb.rho[:,b]),('O_O',do,ob.rho[:,b]),('O_M',do,mb.rho[:,b]),('M_O',dm,ob.rho[:,b]),('M_unit',dm,None),('O_unit',do,None)]:
                                values[cell]+=(dist if rho is None else dist/rho.astype(float)[None,:]).min(1)/bands
                        for cell,value in values.items():
                            assert np.isfinite(value).all();pv=calibrated_p(value[1800:],value[:1800]);alarm=pv<=.04
                            for j,item in enumerate(recipe['records'][100:]*9):
                                if cell in ['M_M','O_O']:
                                    prior_interface='joint' if cell=='M_M' else 'original_reference';oldv,oldp,olda=expected.pop((view,offset,prior_interface,j//200,item['filename']))
                                    error=abs(float(value[j])-oldv);assert error<=1e-7+1e-6*abs(oldv)
                                    assert pv[j]==oldp and str(bool(alarm[j]))==olda;max_anchor=max(max_anchor,error)
                                writer.writerow(dict(encoder=encoder,view=view,year=year,machine=machine,offset=offset,interface=cell,condition=j//200,filename=item['filename'],score=float(value[j]),p_value=float(pv[j]),alarm=bool(alarm[j])))
                                case_count+=1
            assert not expected and case_count==len(views)*6*6*1800
            outputs[str(filename.relative_to(OUT))]=sha(filename);total+=case_count
            anchors.append(dict(encoder=encoder,year=year,machine=machine,max_absolute_score_error=max_anchor,p_alarm_exact=True))
            save('status.json',dict(stage='running',pid=os.getpid(),cases_complete=ci+1,query_score_rows=total,seconds=time.time()-started))
            print('E9',ci+1,'/34',encoder,year,machine,'scores',case_count,flush=True)
    assert total==3304800
    for name,h in inputs.items():assert sha(ROOT/name)==h,name
    save('anchor_validation.json',dict(state='all_1101600_legacy_anchor_scores_reproduced',checks=anchors))
    outputs['anchor_validation.json']=sha(OUT/'anchor_validation.json')
    save('score_seal.json',dict(state='all_E9_scores_sealed_before_label_evaluation',query_score_rows=total,new_query_score_rows=2203200,anchor_query_score_rows=1101600,calibration_score_calculations=183600,new_encodings=0,new_fits=0,seconds=time.time()-started,plan_seal_SHA256=sha(OUT/'plan_seal.json'),outputs=outputs))
    save('status.json',dict(stage='scores_sealed',pid=os.getpid(),cases_complete=34,query_score_rows=total))
    print('E9 all scores sealed; labels were not loaded',flush=True)
if __name__=='__main__':main()
