"""Summarize all fixed E10 cells after independent numerical verification."""
import csv,json,hashlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];B=ROOT/'experiments/results/condition_adaptation/evidence_mechanism_20261022';D=B/'E10_active_window_20261029';E9=B/'E9_factorial_reference_scale_20261028'
CELLS=['M_M','O_O','O_M','M_O','M_unit','O_unit'];OFFSETS=[0,1,7,13,29,43]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):
    with p.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def write(n,rr):
    with (D/n).open('x',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
def main():
    assert not (D/'complete.json').exists()
    numerical=read(D/'evaluation_validation.json');assert sha(D/'metrics.csv')==numerical['metrics_SHA256']
    independent=read(D/'independent_score_validation.json');assert independent['state']=='passed_all_E10_scores_independent_arithmetic'
    seal=read(D/'score_seal.json');assert sha(D/'normal_angles.csv')==seal['outputs']['normal_angles.csv']
    rr=rows(D/'metrics.csv');values={tuple(r[k] for k in ['encoder','view','year','machine','offset','interface','condition']):r for r in rr};assert len(values)==16524
    aa=rows(D/'normal_angles.csv');angles={tuple(r[k] for k in ['encoder','view','year','machine','offset','condition']):float(r['angular_error']) for r in aa};assert len(angles)==2754
    units=sorted({tuple(r[k] for k in ['encoder','view','year','machine']) for r in rr});assert len(units)==51
    machine=[];effects=[]
    for unit in units:
        for offset in map(str,OFFSETS):
            for domain,conditions in [('noisy',range(1,9)),('original',[0])]:
                h={cell:float(np.mean([float(values[unit+(offset,cell,str(c))]['hmean']) for c in conditions])) for cell in CELLS}
                effects.append(dict(zip(['encoder','view','year','machine'],unit),offset=offset,condition_group=domain,coordinate_at_mapped_scale=h['O_M']-h['M_M'],coordinate_at_original_scale=h['O_O']-h['M_O'],scale_at_mapped_coordinates=h['M_O']-h['M_M'],scale_at_original_coordinates=h['O_O']-h['O_M'],interaction=h['O_O']-h['O_M']-h['M_O']+h['M_M'],total_original_minus_joint=h['O_O']-h['M_M']))
            if offset=='0':continue
            da=float(np.mean([angles[unit+(offset,str(c))]-angles[unit+('0',str(c))] for c in range(1,9)]))
            for cell in CELLS:
                pair=[values[unit+('0',cell,str(c))] for c in range(1,9)];shuffle=[values[unit+(offset,cell,str(c))] for c in range(1,9)]
                dh=float(np.mean([float(p['hmean'])-float(s['hmean']) for p,s in zip(pair,shuffle)]));dt=sum(round(100*float(p['oracle_TPR_at_FPR10']))-round(100*float(s['oracle_TPR_at_FPR10'])) for p,s in zip(pair,shuffle))
                machine.append(dict(zip(['encoder','view','year','machine'],unit),offset=int(offset),interface=cell,D_angle=da,D_H=dh,D_TP_sum=dt,angle_lower=da>1e-12,H_counter=da>1e-12 and dh< -1e-12,TPR_counter=da>1e-12 and dt<0))
    ranges=[];aggregate=[]
    for view in ['BEATs','CLS','FM']:
        for cell in CELLS:
            counts=[]
            for offset in OFFSETS[1:]:
                x=[r for r in machine if (r['view'],r['interface'],r['offset'])==(view,cell,offset)];assert len(x)==17
                counts.append(dict(offset=offset,angle_lower=sum(r['angle_lower'] for r in x),H_counter=sum(r['H_counter'] for r in x),TPR_counter=sum(r['TPR_counter'] for r in x)))
            ranges.append(dict(view=view,interface=cell,H_min=min(r['H_counter'] for r in counts),H_max=max(r['H_counter'] for r in counts),TPR_min=min(r['TPR_counter'] for r in counts),TPR_max=max(r['TPR_counter'] for r in counts),per_offset=counts))
        for year in ['2024','2025']:
            for offset in map(str,OFFSETS):
                for cell in CELLS:
                    x=[r for r in rr if (r['view'],r['year'],r['offset'],r['interface'])==(view,year,offset,cell)];n=[r for r in x if r['condition']!='0'];o=[r for r in x if r['condition']=='0']
                    aggregate.append(dict(view=view,year=year,offset=int(offset),interface=cell,noisy_H=float(np.mean([float(r['hmean']) for r in n])),original_H=float(np.mean([float(r['hmean']) for r in o])),noisy_FPR=float(np.mean([float(r['FPR']) for r in n])),noisy_FNR=float(np.mean([float(r['FNR']) for r in n])),D_H_vs_old_window=float(np.mean([float(r['D_H_vs_old_window']) for r in n]))))
    assert len(machine)==1530 and len(effects)==612 and len(aggregate)==216
    write('machine_contrasts.csv',machine);write('factorial_effects.csv',effects);write('aggregate.csv',aggregate)
    (D/'counter_ranges.json').write_text(json.dumps(dict(state='all_fixed_cells_and_offsets_reported',rows=ranges),indent=2)+'\n')
    old={(r['view'],r['interface']):r for r in read(E9/'counter_ranges.json')['rows']}
    report='''# E10 有效录音窗口补充实验

## Material Passport
- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run + validate
- Origin Date: 2026-10-29
- Verification Status: VERIFIED (numerical execution only)
- Version Label: E10_v1

完成全部34编码器案例、65,280次新编码，零新增拟合。六个固定映射设置与六个评分接口全部保留。3,304,800查询分数中367,200个原始条件锚点与E9匹配；16,524条件指标及独立分数复算通过。p值和报警全部一致。

|视图|接口|旧窗口H反例范围|新窗口H反例范围|新窗口oracle TPR反例范围|
|---|---|---:|---:|---:|
'''
    for r in ranges:
        prior=old[r['view'],r['interface']];report+='|'+r['view']+'|'+r['interface']+'|'+str(prior['H_min'])+'–'+str(prior['H_max'])+'|'+str(r['H_min'])+'–'+str(r['H_max'])+'|'+str(r['TPR_min'])+'–'+str(r['TPR_max'])+'|\n'
    report+='''
## 推断边界与统计核对

窗口居中、平滑边缘及短录音处理同时改变，本实验是复合扰动稳健性检查，不能将单项变化作独立因果归因。同一历史录音和模型复用，不是新独立队列、盲测或现场部署验证。五个固定offset不构成独立重复，CLS/FM共享前向。全部原始/新扰动、机器和视图保留，不能以反例减少证明整体检测获益。oracle正常标签预算用于诊断，不能作为部署保证。

11类统计误用均检查：分组与总体差异通过逐年逐视图明细保留；不作生态层级到单机推断；固定公共样本存在选择范围限制；角改善子集仅定义描述性反例；均衡测试基率不能推导现场精确率；不挑极端案例解释均值回归；34案例完整保留避免幸存者筛选；全部控制与接口报告避免多处择优；后验补充协议公开研究分岔；计算干预不推断物理因果；操作顺序不证明现实故障的因果方向。无虚构显著性或独立样本置信区间。
'''
    (D/'报告.md').write_text(report,encoding='utf-8')
    outputs={n:sha(D/n) for n in ['metrics.csv','normal_angles.csv','machine_contrasts.csv','factorial_effects.csv','aggregate.csv','counter_ranges.json','报告.md','evaluation_validation.json','independent_score_validation.json']}
    (D/'complete.json').write_text(json.dumps(dict(state='all_E10_cases_evaluated_and_independently_verified',new_audio_encodings=65280,new_fits=0,query_score_rows=3304800,metric_rows=16524,machine_contrasts=1530,factorial_effect_rows=612,score_seal_SHA256=sha(D/'score_seal.json'),features_seal_SHA256=sha(D/'features_seal.json'),outputs=outputs,ready_for_submission=False),indent=2)+'\n')
    print(report[:500]);print('E10 final report sealed')
if __name__=='__main__':main()
