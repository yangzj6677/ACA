"""Wait for the existing encoder process; execute dependent stages once sealed."""
import ctypes,json,subprocess,sys,time,os
from ctypes import wintypes
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];D=ROOT/'experiments/results/condition_adaptation/evidence_mechanism_20261022/E10_active_window_20261029'
k=ctypes.WinDLL('kernel32',use_last_error=True);k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
k.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];k.CloseHandle.argtypes=[wintypes.HANDLE]
def alive(pid):
    handle=k.OpenProcess(0x1000,False,pid)
    if not handle:return False
    code=wintypes.DWORD()
    try:return bool(k.GetExitCodeProcess(handle,ctypes.byref(code))) and code.value==259
    finally:k.CloseHandle(handle)
status=json.loads((D/'status.json').read_text());pid=status.get('pid');start=time.time()
while not (D/'features_seal.json').exists():
    if time.time()-start>7200:raise TimeoutError('Encoding observation exceeded bounded wait')
    if not pid or not alive(pid):raise RuntimeError('Encoder is terminal without features seal; preserve output and inspect original session, do not restart')
    (D/'pipeline_active.json').write_text(json.dumps(dict(stage='waiting_on_live_encoder',watcher_pid=os.getpid(),encoder_pid=pid))+'\n');time.sleep(10)
for name in ['score_active_window_E10_20261029.py','evaluate_active_window_E10_20261029.py']:
    (D/'pipeline_active.json').write_text(json.dumps(dict(stage=name,watcher_pid=os.getpid()))+'\n')
    with (D/(name+'.log')).open('x',encoding='utf-8') as log:subprocess.run([sys.executable,str(ROOT/'experiments/src'/name)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
(D/'pipeline_active.json').write_text(json.dumps(dict(stage='metrics_checked_pending_independent_score_validation_and_analysis',watcher_pid=os.getpid()))+'\n')
print('E10 scores and condition metrics finished; final independent validation and analysis remain')
