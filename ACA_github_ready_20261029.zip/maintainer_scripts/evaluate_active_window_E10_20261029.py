"""Evaluate every sealed E10 condition with independent ROC and oracle checks."""
import csv,json,hashlib,sys
from pathlib import Path
import numpy as np
from sklearn.metrics import roc_auc_score
ROOT=Path(__file__).resolve().parents[2];PORT=ROOT/'submission/audio_repro_20261028';sys.path.insert(0,str(PORT))
from replay_metrics import metrics,truth
B=ROOT/'experiments/results/condition_adaptation/evidence_mechanism_20261022';D=B/'E10_active_window_20261029';E9=B/'E9_factorial_reference_scale_20261028'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):
    with p.open(encoding='utf-8',newline='') as f:yield from csv.DictReader(f)
def main():
    assert not (D/'metrics.csv').exists(),'Preserve previous evaluation'
    seal=read(D/'score_seal.json');assert seal['state']=='all_E10_scores_sealed_before_label_evaluation'
    assert sha(D/'score_plan_seal.json')==seal['plan_seal_SHA256']
    for n,h in seal['outputs'].items():assert sha(D/n)==h
    for n,h in read(D/'score_plan_seal.json')['inputs'].items():assert sha(ROOT/n)==h
    old={(r['encoder'],r['view'],r['year'],r['machine'],r['offset'],r['interface'],r['condition']):r for r in rows(E9/'metrics.csv')}
    assert sha(E9/'metrics.csv')==read(E9/'complete.json')['outputs']['metrics.csv']
    result=[];maxerror=0.;anchors=0
    for case in read(ROOT/'submission/portable_sensitivity_full_20261028/plan.json')['cases']:
        enc,year,m=[case[k] for k in ['encoder','year','machine']];groups={}
        for r in rows(D/enc/year/m/'scores.csv'):groups.setdefault((r['view'],r['offset'],r['interface'],r['condition']),[]).append(r)
        first=next(iter(groups.values()));names=[r['filename'] for r in first];assert len(names)==len(set(names))==200
        y,domain=truth(ROOT/'experiments/results'/('external'+year),read(PORT/('truth_provenance_'+year+'.json')),year,m,names)
        for (view,offset,cell,condition),rr in groups.items():
            assert [r['filename'] for r in rr]==names
            s=np.array([float(r['score']) for r in rr]);p=np.array([float(r['p_value']) for r in rr]);a=np.array([r['alarm']=='True' for r in rr]);np.testing.assert_array_equal(a,p<=.04)
            v=metrics(y,domain,s,a);expected=[roc_auc_score(y[(domain==d)|(y==1)],s[(domain==d)|(y==1)]) for d in [0,1]]+[roc_auc_score(y,s,max_fpr=.1)]
            error=max(abs(v[k]-x) for k,x in zip(['auc_source','auc_target','pauc'],expected));assert error<1e-12;maxerror=max(maxerror,error)
            threshold=np.r_[np.inf,np.unique(s)];pred=s[None,:]>=threshold[:,None];fp=pred[:,y==0].sum(1);tp=pred[:,y==1].sum(1);assert tp[fp<=10].max()==round(100*v['oracle_TPR_at_FPR10'])
            prior=old[enc,view,year,m,offset,cell,condition]
            if condition=='0':
                for k in ['hmean','FPR','FNR','oracle_TPR_at_FPR10']:assert abs(v[k]-float(prior[k]))<1e-12
                anchors+=1
            result.append(dict(encoder=enc,view=view,year=year,machine=m,offset=int(offset),interface=cell,condition=int(condition),**v,D_H_vs_old_window=v['hmean']-float(prior['hmean']),D_FPR_vs_old_window=v['FPR']-float(prior['FPR']),D_FNR_vs_old_window=v['FNR']-float(prior['FNR'])))
        print('E10 metrics checked',enc,year,m,flush=True)
    assert len(result)==16524 and anchors==1836
    with (D/'metrics.csv').open('x',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(result[0]));w.writeheader();w.writerows(result)
    (D/'evaluation_validation.json').write_text(json.dumps(dict(state='all_E10_condition_metrics_checked_pending_mechanism_analysis',metric_rows=len(result),original_condition_anchor_rows=anchors,max_independent_ROC_error=maxerror,oracle_all_unique_thresholds_checked=True,metrics_SHA256=sha(D/'metrics.csv'),score_seal_SHA256=sha(D/'score_seal.json'),evaluator_SHA256=sha(Path(__file__)),new_independent_cohort=False),indent=2)+'\n')
if __name__=='__main__':main()
