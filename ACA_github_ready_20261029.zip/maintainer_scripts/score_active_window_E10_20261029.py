"""Score sealed E10 features with every frozen E9 map/interface; no labels."""
import csv,hashlib,json,sys,time
from pathlib import Path
import numpy as np
from scipy.spatial.distance import cdist
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parents[2];PORT=ROOT/'submission/audio_repro_20261028';sys.path.insert(0,str(PORT))
from recovery_core import transform,prepare_bank,calibrated_p
BASE=ROOT/'experiments/results/condition_adaptation/evidence_mechanism_20261022';OUT=BASE/'E10_active_window_20261029';E9=BASE/'E9_factorial_reference_scale_20261028';PRIOR=ROOT/'submission/portable_sensitivity_full_20261028'
CELLS=['M_M','O_O','O_M','M_O','M_unit','O_unit'];OFFSETS=[0,1,7,13,29,43]
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def rows(p):
    with p.open(encoding='utf-8',newline='') as f:yield from csv.DictReader(f)
def angular(x,y):
    x=x.astype(float);y=y.astype(float);nx=np.linalg.norm(x,axis=-1,keepdims=True);ny=np.linalg.norm(y,axis=-1,keepdims=True);assert (nx>0).all() and (ny>0).all();return float(np.mean(np.sum((x/nx-y/ny)**2,axis=-1)))
def main():
    assert not (OUT/'score_plan_seal.json').exists(),'Preserve earlier scoring attempt'
    featureseal=read(OUT/'features_seal.json');assert featureseal['state']=='all_new_features_sealed_before_scoring'
    for n,h in featureseal['outputs'].items():assert sha(OUT/n)==h
    cases=read(PRIOR/'plan.json')['cases'];pins={};e9seal=read(E9/'score_seal.json')
    for p in [Path(__file__),PORT/'recovery_core.py',OUT/'features_seal.json',E9/'score_seal.json']:pins[str(p.relative_to(ROOT))]=sha(p)
    for c in cases:
        enc,y,m=[c[k] for k in ['encoder','year','machine']];old=PRIOR/'scores'/enc/y/m;done=read(old/'complete.json')
        for n in ['maps.npz','normal_angles.csv']:assert sha(old/n)==done['outputs'][n];pins[str((old/n).relative_to(ROOT))]=sha(old/n)
        for n,h in done['input_SHA256'].items():assert sha(Path(c['features'])/n)==h;pins[str((Path(c['features'])/n).relative_to(ROOT))]=h
        p=E9/enc/y/m/'scores.csv';assert sha(p)==e9seal['outputs'][str(p.relative_to(E9))];pins[str(p.relative_to(ROOT))]=sha(p)
        assert sha(Path(c['recipe']))==done['recipe_SHA256'];pins[str(Path(c['recipe']).relative_to(ROOT))]=done['recipe_SHA256']
    save(OUT/'score_plan_seal.json',dict(state='all_E10_scoring_inputs_fixed_before_scores',inputs=pins,interfaces=CELLS,offsets=OFFSETS,new_fits=0))
    outputs={};angles=[];anchor_error=0.;anchor_count=0;total=0;started=time.time()
    with threadpool_limits(limits=2):
        for ci,c in enumerate(cases):
            enc,year,machine=[c[k] for k in ['encoder','year','machine']];source=Path(c['features']);recipe=read(Path(c['recipe']));dest=OUT/enc/year/machine
            new=np.load(dest/'features.npz')['projected'];legacy=np.load(source/'features.npz')['projected'];maps=np.load(PRIOR/'scores'/enc/year/machine/'maps.npz')
            if enc=='BEATs':original=np.load(source/'original_projected.npy');lookup={i:i for i in range(1200)};views=['BEATs']
            else:
                loaded=np.load(source/'original_features.npz');original=loaded['projected'];lookup={int(i):j for j,i in enumerate(loaded['ids'])};views=['CLS','FM']
            old={(r['view'],int(r['offset']),r['interface'],r['filename']):(float(r['score']),float(r['p_value']),r['alarm']) for r in rows(E9/enc/year/machine/'scores.csv') if r['condition']=='0'}
            with (dest/'scores.csv').open('x',encoding='utf-8',newline='') as file:
                writer=csv.DictWriter(file,fieldnames=['encoder','view','year','machine','offset','interface','condition','filename','score','p_value','alarm']);writer.writeheader()
                for vi,view in enumerate(views):
                    nf=new if enc=='BEATs' else new[vi];lf=legacy if enc=='BEATs' else legacy[vi];o=original if enc=='BEATs' else original[vi]
                    assert nf.shape[:2]==(8,240);f=np.concatenate([lf[0:1,60:],nf]);bands=f.shape[-2]
                    ref=o[[lookup[i] for i in recipe['reference_ids']]];cal=o[[lookup[i] for i in recipe['calibration_ids']]];ob=prepare_bank(ref)
                    for offset in OFFSETS:
                        w=maps[view+'_shift'+str(offset)];mb=prepare_bank(transform(ref,w));query=transform(np.concatenate([f[:,40:].reshape(-1,bands,128),cal]),w)
                        for condition in range(9):angles.append(dict(encoder=enc,view=view,year=year,machine=machine,offset=offset,condition=condition,angular_error=angular(transform(f[condition,:40],w),f[0,:40])))
                        values={cell:np.zeros(1900) for cell in CELLS}
                        for b in range(bands):
                            dm=np.clip(cdist(query[:,b].astype(float),mb.vectors[:,b].astype(float),'cosine'),0,2)/2;do=np.clip(cdist(query[:,b].astype(float),ob.vectors[:,b].astype(float),'cosine'),0,2)/2
                            for cell,d,rho in [('M_M',dm,mb.rho[:,b]),('O_O',do,ob.rho[:,b]),('O_M',do,mb.rho[:,b]),('M_O',dm,ob.rho[:,b]),('M_unit',dm,None),('O_unit',do,None)]:values[cell]+=(d if rho is None else d/rho.astype(float)[None,:]).min(1)/bands
                        for cell,v in values.items():
                            assert np.isfinite(v).all();pv=calibrated_p(v[1800:],v[:1800])
                            for j,item in enumerate(recipe['records'][100:]*9):
                                if j<200:
                                    ov,op,oa=old.pop((view,offset,cell,item['filename']));error=abs(float(v[j])-ov);assert error<=1e-7+1e-6*abs(ov);assert pv[j]==op and str(bool(pv[j]<=.04))==oa;anchor_error=max(anchor_error,error);anchor_count+=1
                                writer.writerow(dict(encoder=enc,view=view,year=year,machine=machine,offset=offset,interface=cell,condition=j//200,filename=item['filename'],score=float(v[j]),p_value=float(pv[j]),alarm=bool(pv[j]<=.04)));total+=1
            assert not old;outputs[str((dest/'scores.csv').relative_to(OUT))]=sha(dest/'scores.csv');save(OUT/'score_status.json',dict(stage='scoring',cases_complete=ci+1,score_rows=total));print('E10 scored',ci+1,'/34',enc,year,machine,flush=True)
    assert total==3304800 and anchor_count==367200 and len(angles)==2754
    with (OUT/'normal_angles.csv').open('x',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(angles[0]));w.writeheader();w.writerows(angles)
    outputs['normal_angles.csv']=sha(OUT/'normal_angles.csv')
    for p,h in pins.items():assert sha(ROOT/p)==h
    save(OUT/'score_seal.json',dict(state='all_E10_scores_sealed_before_label_evaluation',query_score_rows=total,new_query_scores=2937600,original_condition_anchor_scores=anchor_count,anchor_max_absolute_error=anchor_error,anchor_p_alarm_exact=True,normal_angle_rows=2754,outputs=outputs,plan_seal_SHA256=sha(OUT/'score_plan_seal.json'),seconds=time.time()-started))
    print('E10 all scores sealed; evaluation not yet run',flush=True)
if __name__=='__main__':main()
