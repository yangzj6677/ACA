"""Evaluate sealed E9 cells; independently check ROC and whole-tie oracle budgets."""
import csv,hashlib,json,sys,time
from pathlib import Path
import numpy as np
from sklearn.metrics import roc_auc_score
ROOT=Path(__file__).resolve().parents[2];PORT=ROOT/'submission/audio_repro_20261028';sys.path.insert(0,str(PORT))
from replay_metrics import metrics,truth
BASE=ROOT/'experiments/results/condition_adaptation/evidence_mechanism_20261022';OUT=BASE/'E9_factorial_reference_scale_20261028';PRIOR=ROOT/'submission/portable_sensitivity_full_20261028'
CELLS=['M_M','O_O','O_M','M_O','M_unit','O_unit'];OFFSETS=[0,1,7,13,29,43]
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(name,rr):
    with (OUT/name).open('x',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def main():
    assert not (OUT/'complete.json').exists()
    seal=read(OUT/'score_seal.json');assert seal['state']=='all_E9_scores_sealed_before_label_evaluation'
    assert sha(OUT/'plan_seal.json')==seal['plan_seal_SHA256']
    for n,h in seal['outputs'].items():assert sha(OUT/n)==h,n
    for n,h in read(OUT/'plan_seal.json')['inputs'].items():assert sha(ROOT/n)==h,n
    provenance={y:read(PORT/('truth_provenance_'+y+'.json')) for y in ['2024','2025']}
    all_metrics=[];machine=[];effects=[];maxerr=0.;anchor_metrics=0;started=time.time()
    for ci,c in enumerate(read(PRIOR/'plan.json')['cases']):
        encoder,year,name=[c[k] for k in ['encoder','year','machine']];path=OUT/encoder/year/name/'scores.csv';group={}
        for r in rows(path):group.setdefault((r['view'],int(r['offset']),r['interface'],int(r['condition'])),[]).append(r)
        olddir=PRIOR/'evaluation'/encoder/year/name;olddone=read(olddir/'complete.json');assert sha(olddir/'metrics.csv')==olddone['outputs']['metrics.csv']
        old={(r['view'],int(r['offset']),r['interface'],int(r['condition'])):r for r in rows(olddir/'metrics.csv')}
        first=next(iter(group.values()));names=[r['filename'] for r in first];assert len(names)==len(set(names))==200
        y,d=truth(ROOT/'experiments/results'/('external'+year),provenance[year],year,name,names);values={}
        for (view,offset,cell,condition),rr in group.items():
            assert [r['filename'] for r in rr]==names
            s=np.array([float(r['score']) for r in rr]);p=np.array([float(r['p_value']) for r in rr]);alarm=np.array([r['alarm']=='True' for r in rr]);np.testing.assert_array_equal(alarm,p<=.04)
            v=metrics(y,d,s,alarm)
            expected=[roc_auc_score(y[(d==domain)|(y==1)],s[(d==domain)|(y==1)]) for domain in [0,1]]+[roc_auc_score(y,s,max_fpr=.1)]
            err=max(abs(v[n]-a) for n,a in zip(['auc_source','auc_target','pauc'],expected));assert err<1e-12;maxerr=max(maxerr,err)
            threshold=np.r_[np.inf,np.unique(s)];prediction=s[None,:]>=threshold[:,None];fp=prediction[:,y==0].sum(1);tp=prediction[:,y==1].sum(1)
            assert tp[fp<=10].max()==round(100*v['oracle_TPR_at_FPR10'])
            if cell in ['M_M','O_O']:
                legacy='joint' if cell=='M_M' else 'original_reference';oldv=old.pop((view,offset,legacy,condition))
                for n in ['auc_source','auc_target','pauc','hmean','FPR','FNR','oracle_TPR_at_FPR10']:assert abs(v[n]-float(oldv[n]))<1e-12
                anchor_metrics+=1
            record=dict(encoder=encoder,view=view,year=year,machine=name,offset=offset,interface=cell,condition=condition,**v);all_metrics.append(record);values[view,offset,cell,condition]=record
        assert not old
        oldscores=PRIOR/'scores'/encoder/year/name;oldseal=read(oldscores/'complete.json');assert sha(oldscores/'normal_angles.csv')==oldseal['outputs']['normal_angles.csv']
        angles={(r['view'],int(r['offset']),int(r['condition'])):float(r['angular_error']) for r in rows(oldscores/'normal_angles.csv')}
        views=['BEATs'] if encoder=='BEATs' else ['CLS','FM']
        for view in views:
            for offset in OFFSETS:
                for domain,conditions in [('noisy',range(1,9)),('original',[0])]:
                    avg={cell:float(np.mean([values[view,offset,cell,q]['hmean'] for q in conditions])) for cell in CELLS}
                    effects.append(dict(encoder=encoder,view=view,year=year,machine=name,offset=offset,condition_group=domain,coordinate_at_mapped_scale=avg['O_M']-avg['M_M'],coordinate_at_original_scale=avg['O_O']-avg['M_O'],scale_at_mapped_coordinates=avg['M_O']-avg['M_M'],scale_at_original_coordinates=avg['O_O']-avg['O_M'],interaction=avg['O_O']-avg['O_M']-avg['M_O']+avg['M_M'],total_original_minus_joint=avg['O_O']-avg['M_M'],plain_original_minus_mapped=avg['O_unit']-avg['M_unit']))
                if offset==0:continue
                da=float(np.mean([angles[view,offset,q]-angles[view,0,q] for q in range(1,9)]))
                for cell in CELLS:
                    dh=float(np.mean([values[view,0,cell,q]['hmean']-values[view,offset,cell,q]['hmean'] for q in range(1,9)]))
                    dt=sum(round(100*values[view,0,cell,q]['oracle_TPR_at_FPR10'])-round(100*values[view,offset,cell,q]['oracle_TPR_at_FPR10']) for q in range(1,9))
                    machine.append(dict(encoder=encoder,view=view,year=year,machine=name,offset=offset,interface=cell,D_angle=da,D_H=dh,D_TP_sum=dt,angle_lower=da>1e-12,H_counter=da>1e-12 and dh < -1e-12,TPR_counter=da>1e-12 and dt<0))
        print('E9 evaluated',ci+1,'/34',encoder,year,name,flush=True)
    assert len(all_metrics)==16524 and anchor_metrics==5508 and len(machine)==1530 and len(effects)==612
    aggregates=[]
    for view in ['BEATs','CLS','FM']:
        for year in ['2024','2025']:
            for offset in OFFSETS:
                for cell in CELLS:
                    rr=[r for r in all_metrics if r['view']==view and r['year']==year and r['offset']==offset and r['interface']==cell];noisy=[r for r in rr if r['condition']>0];orig=[r for r in rr if r['condition']==0]
                    aggregates.append(dict(view=view,year=year,offset=offset,interface=cell,machine_cases=len(orig),noisy_H=float(np.mean([r['hmean'] for r in noisy])),original_H=float(np.mean([r['hmean'] for r in orig])),noisy_FPR=float(np.mean([r['FPR'] for r in noisy])),noisy_FNR=float(np.mean([r['FNR'] for r in noisy])),noisy_oracle_TPR10=float(np.mean([r['oracle_TPR_at_FPR10'] for r in noisy]))))
    ranges=[]
    for view in ['BEATs','CLS','FM']:
        for cell in CELLS:
            counts=[]
            for offset in OFFSETS[1:]:
                rr=[r for r in machine if r['view']==view and r['interface']==cell and r['offset']==offset];assert len(rr)==17
                counts.append(dict(offset=offset,angular_improvement=sum(r['angle_lower'] for r in rr),H_counter=sum(r['H_counter'] for r in rr),TPR_counter=sum(r['TPR_counter'] for r in rr)))
            ranges.append(dict(view=view,interface=cell,H_min=min(r['H_counter'] for r in counts),H_max=max(r['H_counter'] for r in counts),TPR_min=min(r['TPR_counter'] for r in counts),TPR_max=max(r['TPR_counter'] for r in counts),per_offset=counts))
    write('metrics.csv',all_metrics);write('machine_contrasts.csv',machine);write('factorial_effects.csv',effects);write('aggregate.csv',aggregates);save('counter_ranges.json',dict(state='all_cells_offsets_views_reported',rows=ranges))
    save('evaluation_validation.json',dict(state='passed',metric_rows=16524,legacy_anchor_metric_rows=5508,max_independent_sklearn_error=maxerr,oracle_all_unique_thresholds_checked=True,alarm_rule_checked=True,descriptive_only=True,no_independent_offsets_or_views_claim=True))
    outputs={n:sha(OUT/n) for n in ['metrics.csv','machine_contrasts.csv','factorial_effects.csv','aggregate.csv','counter_ranges.json','evaluation_validation.json']}
    save('complete.json',dict(state='all_E9_factorial_cells_evaluated',query_score_rows=3304800,new_query_score_rows=2203200,metric_rows=16524,machine_contrasts=1530,factorial_effect_rows=612,new_encodings=0,new_fits=0,seconds=time.time()-started,score_seal_SHA256=sha(OUT/'score_seal.json'),evaluator_SHA256=sha(Path(__file__)),metric_core_SHA256=sha(PORT/'replay_metrics.py'),outputs=outputs,ready_for_submission=False))
    print('E9 all six interfaces evaluated; numerical validation passed',flush=True)
if __name__=='__main__':main()
