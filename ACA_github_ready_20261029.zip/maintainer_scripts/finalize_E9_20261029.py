import json,csv,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];D=ROOT/'experiments/results/condition_adaptation/evidence_mechanism_20261022/E9_factorial_reference_scale_20261028'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
done=json.loads((D/'complete.json').read_text());ind=json.loads((D/'independent_score_validation.json').read_text())
for n,h in done['outputs'].items():assert sha(D/n)==h
assert ind['state']=='passed_all_E9_scores_independent_arithmetic' and ind['all_p_values_and_alarms_exact']
ranges=json.loads((D/'counter_ranges.json').read_text())['rows']
text='''# E9 实验与核验报告

## Material Passport
- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run + validate
- Origin Date: 2026-10-29
- Verification Status: VERIFIED (arithmetic execution scope)
- Version Label: E9_v1

全部34编码器案例完成，3,304,800查询分数、16,524条件指标、1,530机器级对照。无新编码、无新拟合。旧接口1,101,600锚点匹配；独立归一化矩阵乘法重算全部分数，p值和报警完全匹配，最大绝对分数差为'''+str(ind['max_absolute_score_error'])+'''。ROC另用sklearn核对，oracle检查全部唯一阈值及完整并列组。

M/O分别表示映射后/原始参考坐标或局部尺度；unit表示取消局部尺度、普通逐带余弦最近邻。下表是五个固定offset下反例数量的最小—最大值，不是置信区间。

|视图|参考坐标/尺度|H反例范围|oracle TPR反例范围|
|---|---|---:|---:|
'''
for r in ranges:text+='|'+r['view']+'|'+r['interface']+'|'+str(r['H_min'])+'–'+str(r['H_max'])+'|'+str(r['TPR_min'])+'–'+str(r['TPR_max'])+'|\n'
text+='''
去掉局部尺度后仍有角恢复与检测排序反转，不能把全部反例解释为该归一化项的产物。不同坐标与尺度组合也改变反例数；参考接口的作用必须按条件报告，不能宣称原始参考是普适修复。普通余弦后端并未因此成为更优检测器。

所有原始条件与扰动条件、全部offset和视图均保留于aggregate.csv、metrics.csv与factorial_effects.csv。factorial_effects的坐标差是在固定尺度下比较，尺度差是在固定坐标下比较；交互为描述性差分，不作百分比因果归因。E10尚需独立执行和评价，E9不构成新声学队列确认。

## 统计误用核对（11/11）
|项目|核对与边界|
|---|---|
|Simpson悖论|逐年、逐视图及机器明细保留，不以混合总体替代分组|
|生态谬误|均值与反例数不用于推断每台机器均受益|
|Berkson选择偏差|固定公共案例属受限样本，不作工业总体推断|
|碰撞变量偏差|角恢复更好子集仅用于定义描述性反例，完整案例同时保留|
|基率忽视|测试正常/异常均衡，不能推导现场阳性预测值|
|均值回归|未挑最差案例重测；全部17案例统一处理|
|幸存者偏差|34编码器案例全部完成，无静默剔除|
|多处寻找效应|全部6接口、5控制均报告，无显著性筛选|
|分岔路径|协议在E9执行前固定，但在历史结果之后形成，明确后验性质|
|相关冒充因果|限定固定计算干预，不推断物理故障机制或实际部署因果|
|反向因果|记录评分操作方向；不把计算依赖解释为真实声学因果|

本实验不提供独立样本显著性检验或置信区间；操作性校准p值不是假设检验的显著性证据。执行验证不证明创新性或投稿可接受性。
'''
(D/'报告.md').write_text(text,encoding='utf-8')
(D/'analysis_seal.json').write_text(json.dumps(dict(state='E9_report_and_validation_sealed',outputs={n:sha(D/n) for n in ['报告.md','independent_score_validation.json','complete.json']},ready_for_submission=False),indent=2)+'\n')
print('E9 report and 11-type interpretation audit sealed')
