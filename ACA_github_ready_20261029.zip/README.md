# ACA: normal-representation recovery and score geometry

ACA is a research code and reproducibility candidate for a controlled anomalous-sound-detection study using fixed pretrained representations, normal-only analytic adaptation, and sensitivity analyses of scoring geometry. This is a local draft, not a public release or a claim of deployment validation.

## Contents

- `reproduce/`: independent E4 BEATs and E5 ECHOv2 per-case audio-to-score replay, E8 pairing/reference sensitivity, metric replay, fixed recipes and Python requirements. See [its detailed instructions](reproduce/README.md).
- `maintainer_scripts/`, `protocols/`, `recipes/active_window/`: historical E9 factorial reference/scale and E10 active-window analyses and their fixed recipes. These scripts require the old experiment workspace and previously sealed features/maps; they are not a standalone E9/E10 pipeline.
- `validation_evidence/`: summaries of the earlier full audio and sensitivity replays. These document execution on the same data, not an independent cohort.

## Setup and example

The recorded environment uses Python 3.12.11 and the packages in `reproduce/requirements.txt`; the PyTorch CUDA build and suitable NVIDIA driver must match the local machine. See the [PyTorch installation instructions](https://pytorch.org/get-started/locally/) before installing the remaining requirements. BEATs replay requires CUDA; the ECHO CPU option was not validated for a complete rerun. Different hardware may change floating-point results. The requirements include some packages without pinned versions, so they do not fully lock an environment.

From the project root, with a compatible environment and external assets in place:

```shell
python reproduce/run_echo.py --recipe reproduce/recipes/2024_3DPrinter.json --data-root DATA_ROOT --vendor ECHO_SOURCE --checkpoint MODEL_SAFETENSORS --output NEW_OUTPUT_DIRECTORY
python reproduce/run_beats.py --recipe reproduce/beats_recipes/2024_3DPrinter.json --data-root DATA_ROOT --vendor BEATS_SOURCE --checkpoint BEATS_CHECKPOINT --output ANOTHER_NEW_OUTPUT_DIRECTORY
```

These commands verify input hashes and preserve existing output directories. Source trees, WAVs and checkpoints are not included; no downloads occur. Obtain the correct pinned versions and follow the detailed [reproduction notes](reproduce/README.md) and [source and evaluator provenance](reproduce/REFERENCES.md). Official evaluator truth files are needed for metric replay, separately from model fitting. The BEATs-family checkpoint was obtained from a pinned public mirror; equivalence to the upstream release remains unverified.

## Data and interpretation

The separate local `research_data_deposit_candidate_20261029.zip` (140,716,217 bytes) contains derived scores and diagnostics; it is not included in this project directory and has not yet been deposited. A public dataset URL or DOI must be added only after a real deposit. The 8,170,200 score rows include repeated conditions and controls, not independent recordings. The original [2024 training](https://zenodo.org/records/11259435), [2024 evaluation](https://zenodo.org/records/11363076), [2025 training](https://zenodo.org/records/15392814) and [2025 evaluation](https://zenodo.org/records/15519362) sources specify CC BY-NC-SA 4.0; verify applicability to derived outputs before assigning their license.

The results are on benchmark recordings with synthetic disturbances. Historical exposure and unknown parent/pretraining overlap restrict generalization. E10 changes several perturbation properties together. Oracle test-label threshold metrics are diagnostic and are not deployment thresholds.

## License and release state

The project-owned original Python code is offered under [MIT](LICENSE). The authors have selected CC BY-NC-SA 4.0 for their derived data, subject to verification of source rights and applicability before release. See [license scope and source attribution](LICENSES.md); external assets retain their own terms. The target [ACA repository](https://github.com/yangzj6677/ACA) exists and currently contains only its initial README; this candidate has not been uploaded. The research-data repository has not been selected, and the data have not been deposited.
