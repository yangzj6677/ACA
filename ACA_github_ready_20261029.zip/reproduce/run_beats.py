"""Standalone BEATs-family E4 audio replay, preserving the batch-eight interface."""
import argparse,csv,json,sys,time
from pathlib import Path
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from recovery_core import project,fit_map,transform,prepare_bank,score,calibrated_p
from run_echo import sha,read,decode,digest,setup,METHODS
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--recipe',type=Path,required=True);ap.add_argument('--data-root',type=Path,required=True)
    ap.add_argument('--vendor',type=Path,required=True);ap.add_argument('--checkpoint',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True);ap.add_argument('--expected',type=Path)
    a=ap.parse_args();recipe=read(a.recipe);root=a.data_root.resolve();out=a.output.resolve()
    if out.exists():raise ValueError('Preserve prior attempt; use a new output directory')
    assert torch.cuda.is_available() and sha(a.checkpoint)==recipe['checkpoint_SHA256']
    for n,h in recipe['vendor_files'].items():assert sha(a.vendor/n)==h,n
    for n,h in recipe['audio_inputs'].items():
        p=(root/n).resolve();assert p.is_relative_to(root) and sha(p)==h,n
    if a.expected:
        for n,h in recipe['expected_files'].items():assert sha(a.expected/n)==h,n
    out.mkdir(parents=True);setup();sys.path.insert(0,str(a.vendor.resolve()))
    from beats.BEATs import BEATs,BEATsConfig
    ck=torch.load(a.checkpoint,map_location='cpu',weights_only=True);model=BEATs(BEATsConfig(ck['cfg']))
    model.load_state_dict(ck['model'],strict=True);del ck;model=model.eval().requires_grad_(False).cuda()
    def encode(waves):
        assert len(waves)==8
        q=torch.tensor(np.stack(waves),device='cuda')
        with torch.autocast('cuda',dtype=torch.bfloat16):_,_,layers=model.extract_features(q,layer=11,need_weights=False)
        pooled=layers[-1][0].transpose(0,1).reshape(8,62,8,768).mean(1).float().cpu().numpy()
        assert np.isfinite(pooled).all();return pooled
    def status(stage,n,total):
        (out/'status.json').write_text(json.dumps(dict(stage=stage,records=n,total=total))+'\n');print(stage,n,'/',total,flush=True)
    begin=time.time();original=np.empty((1200,8,768),np.float32)
    assert [r['id'] for r in recipe['originals']]==list(range(1200))
    for low in range(0,1200,8):
        original[low:low+8]=encode([decode(root/r['path']) for r in recipe['originals'][low:low+8]])
        if (low+8)%80==0:status('original_encoding',low+8,1200)
    raw=np.empty((9,300,8,768),np.float32);noise_cache={};wave_checks=0
    for j,r in enumerate(recipe['records']):
        base=decode(root/r['path']);raw[0,j]=original[r['id']];variants=[]
        for c,v in enumerate(r['conditions']):
            if c==0:wave=base
            else:
                n=v['noise_path']
                if n not in noise_cache:noise_cache[n]=decode(root/n,noise=True)
                added=(noise_cache[n]*v['beta']).astype(np.float32);wave=base.copy();wave[:96000]=(base[:96000]+added).astype(np.float32)
                assert np.array_equal(wave[96000:],base[96000:]);variants.append(wave)
            assert digest(wave)==v['waveform_SHA256'],(r['id'],c);wave_checks+=1
        raw[1:,j]=encode(variants)
        if (j+1)%20==0:status('mixture_encoding',j+1,300)
    validation={};models={};rows=[]
    with threadpool_limits(limits=2):
        original_projected,_=project(original,768,8);mixed,_=project(raw,768,8)
        np.save(out/'original_projected.npy',original_projected);np.savez(out/'features.npz',raw_pooled=raw,projected=mixed)
        if a.expected:
            expected=np.load(a.expected/'features.npz')['raw_pooled'];np.testing.assert_allclose(raw,expected,atol=1e-6,rtol=1e-5)
            validation['raw_features']=dict(max_absolute_error=float(np.max(abs(raw-expected))),bitwise_equal=bool(np.array_equal(raw,expected)))
            expected=np.load(a.expected/'original_projected.npy');np.testing.assert_allclose(original_projected,expected,atol=1e-7,rtol=1e-6)
            validation['original_projected']=dict(max_absolute_error=float(np.max(abs(original_projected-expected))),bitwise_equal=bool(np.array_equal(original_projected,expected)))
        for method in METHODS:
            w=fit_map(mixed[:,:100],method)
            if w is not None:models[method]=w
            bank=prepare_bank(transform(original_projected[recipe['reference_ids']],w));cal=transform(original_projected[recipe['calibration_ids']],w)
            values=score(bank,np.concatenate([transform(mixed[:,100:].reshape(-1,8,128),w),cal]));p=calibrated_p(values[1800:],values[:1800])
            for index,r in enumerate(recipe['records'][100:]*9):
                rows.append(dict(year=recipe['year'],machine=recipe['machine'],method=method,condition=index//200,id=r['id'],filename=r['filename'],score=float(values[index]),p_value=float(p[index]),alarm=bool(p[index]<=.04)))
        np.savez(out/'maps.npz',**models)
    with (out/'scores.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    if a.expected:
        with (a.expected/'scores.csv').open(encoding='utf-8',newline='') as f:prior=list(csv.DictReader(f))
        assert len(rows)==len(prior)==7200
        for got,old in zip(rows,prior):assert all(str(got[k])==old[k] for k in ['method','condition','id','filename','alarm'])
        actual=np.array([r['score'] for r in rows]);expected=np.array([float(r['score']) for r in prior]);np.testing.assert_allclose(actual,expected,atol=1e-7,rtol=1e-6)
        np.testing.assert_array_equal([r['p_value'] for r in rows],[float(r['p_value']) for r in prior])
        validation['scores']=dict(max_absolute_error=float(np.max(abs(actual-expected))),p_alarm_exact=True)
        expected=np.load(a.expected/'maps.npz')
        for name,value in models.items():np.testing.assert_allclose(value,expected[name],atol=1e-7,rtol=1e-6)
    result=dict(state='passed',dataset=recipe['year']+'/'+recipe['machine'],audio_encodings=3600,score_rows=len(rows),analytic_maps=3,
        waveform_hashes_verified=wave_checks,labels_read=False,encoder_training_runs=0,comparison=validation,seconds=time.time()-begin,
        recipe_SHA256=sha(a.recipe),script_SHA256=sha(Path(__file__)),core_SHA256=sha(Path(__file__).with_name('recovery_core.py')),
        shared_decode_setup_script_SHA256=sha(Path(__file__).with_name('run_echo.py')),
        outputs={n:sha(out/n) for n in ['original_projected.npy','features.npz','maps.npz','scores.csv']})
    (out/'complete.json').write_text(json.dumps(result,indent=2)+'\n');status('complete',3600,3600)
if __name__=='__main__':main()
