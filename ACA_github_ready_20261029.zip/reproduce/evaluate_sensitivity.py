"""Portable evaluation of one complete sensitivity case using pinned official truth."""
import argparse,csv,json,hashlib
from pathlib import Path
import numpy as np
from replay_metrics import metrics,truth
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(p,rr):
    with p.open('x',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);ap.add_argument('--truth',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    source=a.results;done=json.loads((source/'complete.json').read_text());assert done['state']=='completed_without_labels'
    for n,h in done['outputs'].items():assert sha(source/n)==h,n
    if a.output.exists():raise ValueError('Preserve existing evaluation; use a new output directory')
    rr=rows(source/'scores.csv');groups={}
    for r in rr:groups.setdefault((r['view'],int(r['offset']),r['interface'],int(r['condition'])),[]).append(r)
    first=rr[0];year=first['year'];machine=first['machine'];provenance=json.loads((Path(__file__).parent/('truth_provenance_'+year+'.json')).read_text())
    names=[r['filename'] for r in next(iter(groups.values()))];y,d=truth(a.truth,provenance,year,machine,names);mm=[]
    for (view,offset,interface,c),items in groups.items():
        assert [r['filename'] for r in items]==names and all(r['year']==year and r['machine']==machine for r in items)
        score=np.array([float(r['score']) for r in items]);p=np.array([float(r['p_value']) for r in items]);alarm=np.array([r['alarm']=='True' for r in items]);np.testing.assert_array_equal(alarm,p<=.04)
        mm.append(dict(encoder=first['encoder'],view=view,year=year,machine=machine,offset=offset,interface=interface,condition=c,**metrics(y,d,score,alarm)))
    angles={(r['view'],int(r['offset']),int(r['condition'])):float(r['angular_error']) for r in rows(source/'normal_angles.csv')}
    values={(r['view'],r['offset'],r['interface'],r['condition']):r for r in mm};contrasts=[]
    for view in done['views']:
        for offset in [1,7,13,29,43]:
            da=float(np.mean([angles[view,offset,c]-angles[view,0,c] for c in range(1,9)]))
            for interface in ['joint','original_reference']:
                dh=[];dt=0
                for c in range(1,9):
                    pair=values[view,0,interface,c];shuffle=values[view,offset,interface,c]
                    dh.append(pair['hmean']-shuffle['hmean']);dt+=round(100*pair['oracle_TPR_at_FPR10'])-round(100*shuffle['oracle_TPR_at_FPR10'])
                h=float(np.mean(dh));contrasts.append(dict(encoder=first['encoder'],view=view,year=year,machine=machine,offset=offset,interface=interface,D_angle=da,D_H=h,D_T=dt/800,D_TP_sum=dt,angle_lower=da>1e-12,H_counter=da>1e-12 and h < -1e-12,TPR_counter=da>1e-12 and dt<0))
    a.output.mkdir(parents=True);write(a.output/'metrics.csv',mm);write(a.output/'machine_contrasts.csv',contrasts)
    (a.output/'complete.json').write_text(json.dumps(dict(state='evaluated_with_pinned_truth',dataset=year+'/'+machine,metric_rows=len(mm),machine_contrasts=len(contrasts),score_rows=len(rr),score_input_SHA256=sha(source/'scores.csv'),script_SHA256=sha(Path(__file__)),outputs={n:sha(a.output/n) for n in ['metrics.csv','machine_contrasts.csv']},historical_data_exposed=True,independent_offset_or_view_claim=False,oracle_is_diagnostic_only=True),indent=2)+'\n')
    print(year,machine,len(mm),'metric rows and',len(contrasts),'machine contrasts')
if __name__=='__main__':main()
