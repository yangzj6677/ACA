"""Replay E4 from frozen projected features and maps using portable CPU math."""
import argparse,csv,hashlib,json,time
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from recovery_core import fit_map,transform,prepare_bank,score,calibrated_p

METHODS=['identity','residual_ridge','covariance_only','shuffled_target']
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def csvrows(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--results',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--fit-datasets',type=int,default=2);args=parser.parse_args()
    root=args.results.resolve();complete=read(root/'complete.json');seal=read(root/'seal.json')
    if sha(root/'seal.json')!=complete['score_seal_SHA256']:raise ValueError('Experiment seal mismatch')
    plan=read(root/'plan.json');allrows=csvrows(root/'scores.csv');lookup={}
    for row in allrows:lookup.setdefault((row['year'],row['machine'],row['method']),[]).append(row)
    checks=[];started=time.time();verified=0
    with threadpool_limits(limits=2):
        for dataset_index,(qualified,mp) in enumerate(plan['datasets'].items()):
            folder=root/mp['year']/mp['machine']
            for name in ['features.npz','original_projected.npy','maps.npz','scores.csv']:
                relative=(folder/name).relative_to(root).as_posix()
                if sha(folder/name)!=seal['outputs'][relative]:raise ValueError('Frozen input mismatch: '+relative)
            features=np.load(folder/'features.npz')['projected'];original=np.load(folder/'original_projected.npy');stored=np.load(folder/'maps.npz')
            max_error=0.;max_map_error=0.
            for method in METHODS:
                mapping=None if method=='identity' else stored[method]
                if mapping is not None and dataset_index<args.fit_datasets:
                    recovered=fit_map(features[:,:100],method)
                    np.testing.assert_allclose(recovered,mapping,atol=1e-7,rtol=1e-6)
                    max_map_error=max(max_map_error,float(np.max(abs(recovered-mapping))))
                bank=prepare_bank(transform(original[mp['reference_ids']],mapping))
                calibration=transform(original[mp['calibration_ids']],mapping)
                queries=transform(features[:,100:].reshape(-1,8,128),mapping)
                values=score(bank,np.concatenate([queries,calibration]));p=calibrated_p(values[1800:],values[:1800])
                prior=lookup[mp['year'],mp['machine'],method]
                if len(prior)!=1800:raise ValueError('Expected all nine conditions and 200 records')
                expected=np.array([float(v['score']) for v in prior]);expected_p=np.array([float(v['p_value']) for v in prior])
                expected_alarm=np.array([v['alarm']=='True' for v in prior])
                np.testing.assert_allclose(values[:1800],expected,atol=1e-7,rtol=1e-6)
                np.testing.assert_array_equal(p,expected_p);np.testing.assert_array_equal(p<=.04,expected_alarm)
                max_error=max(max_error,float(np.max(abs(values[:1800]-expected))));verified+=len(prior)
            checks.append(dict(dataset=qualified,rows=7200,max_score_error=max_error,max_refit_map_error=max_map_error,
                               fitting_replayed=dataset_index<args.fit_datasets,p_alarm_exact=True))
            print(qualified,'portable CPU replay passed',flush=True)
    if verified!=122400:raise ValueError('Incomplete replay')
    result=dict(state='passed',score_rows=verified,checks=checks,fit_datasets=args.fit_datasets,
        scope='All E4 scores/p/alarms; refit maps on the requested leading datasets. Does not rerun encoders.',
        seconds=time.time()-started,source_experiment_complete_SHA256=sha(root/'complete.json'))
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')

if __name__=='__main__':main()
