"""Standalone E5 audio-to-score replay. No project experiment modules or labels."""
import argparse, csv, hashlib, io, json, sys, time
from pathlib import Path
import numpy as np
import torch
from scipy.io import wavfile
from safetensors.torch import load_file
from threadpoolctl import threadpool_limits
from recovery_core import project, fit_map, transform, prepare_bank, score, calibrated_p

METHODS=['identity','residual_ridge','covariance_only','shuffled_target']
VIEWS=['CLS','FM']
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def digest(a):return hashlib.sha256(a.tobytes()).hexdigest()
def decode(path,noise=False):
    sr,a=wavfile.read(io.BytesIO(path.read_bytes()));assert sr==16000 and a.ndim==1
    if noise:
        if a.dtype.kind=='i':a=a.astype(np.float32)/2**(np.iinfo(a.dtype).bits-1)
        else:assert a.dtype.kind=='f';a=a.astype(np.float32)
        assert len(a)>=96000 and np.isfinite(a).all();return a[:96000]
    assert a.dtype.kind=='i' and a.dtype.itemsize in (2,4)
    a=(a.astype(np.float32)/float(2**(np.iinfo(a.dtype).bits-1))).astype(np.float32)
    a=np.pad(a[:160000],(0,max(0,160000-len(a))));assert np.isfinite(a).all();return a
def setup():
    torch.set_num_threads(4);torch.set_grad_enabled(False);torch.manual_seed(11)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.backends.mha.set_fastpath_enabled(False);torch.backends.cuda.enable_flash_sdp(False)
    torch.backends.cuda.enable_mem_efficient_sdp(False);torch.backends.cuda.enable_math_sdp(True)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--recipe',type=Path,required=True);ap.add_argument('--data-root',type=Path,required=True)
    ap.add_argument('--vendor',type=Path,required=True);ap.add_argument('--checkpoint',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True);ap.add_argument('--expected',type=Path)
    ap.add_argument('--device',choices=['cuda','cpu'],default='cuda');a=ap.parse_args()
    recipe=read(a.recipe);root=a.data_root.resolve();out=a.output.resolve()
    if out.exists():raise ValueError('Use a new output directory; existing artifacts are preserved')
    assert sha(a.checkpoint)==recipe['checkpoint_SHA256']
    for name,h in recipe['vendor_files'].items():assert sha(a.vendor/name)==h,name
    for name,h in recipe['audio_inputs'].items():
        p=(root/name).resolve();assert p.is_relative_to(root) and sha(p)==h,name
    if a.expected:
        for name,h in recipe['expected_files'].items():assert sha(a.expected/name)==h,name
    out.mkdir(parents=True);setup();sys.path.insert(0,str(a.vendor.resolve()))
    from src.audioMAE_band_upgrade import AudioMAEWithBand
    from src.utils import sanitize_state_dict
    model=AudioMAEWithBand();model.load_state_dict(sanitize_state_dict(load_file(str(a.checkpoint))),strict=True)
    model=model.eval().requires_grad_(False).to(a.device)
    def encode(wave):
        cls,frames=model.extract_features_from_audio(torch.from_numpy(wave).unsqueeze(0),16000)
        assert cls.shape==(2688,) and frames.shape==(63,2688)
        return np.stack([cls.numpy().reshape(7,384),frames.mean(0).numpy().reshape(7,384)])
    def status(stage,n,total):
        (out/'status.json').write_text(json.dumps(dict(stage=stage,records=n,total=total))+'\n')
        print(stage,n,'/',total,flush=True)
    begin=time.time();original=np.empty((2,900,7,384),np.float32)
    ids=[r['id'] for r in recipe['originals']];lookup={v:i for i,v in enumerate(ids)}
    for j,r in enumerate(recipe['originals']):
        original[:,j]=encode(decode(root/r['path']))
        if (j+1)%100==0:status('original_encoding',j+1,900)
    raw=np.empty((2,9,300,7,384),np.float32);noise_cache={};wave_checks=0
    for j,r in enumerate(recipe['records']):
        base=decode(root/r['path']);raw[:,0,j]=original[:,lookup[r['id']]]
        for c,v in enumerate(r['conditions']):
            if c==0:wave=base
            else:
                name=v['noise_path']
                if name not in noise_cache:noise_cache[name]=decode(root/name,noise=True)
                added=(noise_cache[name]*v['beta']).astype(np.float32);wave=base.copy()
                wave[:96000]=(base[:96000]+added).astype(np.float32)
                assert np.array_equal(wave[96000:],base[96000:]);raw[:,c,j]=encode(wave)
            assert digest(wave)==v['waveform_SHA256'],(r['id'],c);wave_checks+=1
        if (j+1)%20==0:status('mixture_encoding',j+1,300)
    # Project a view/condition jointly, matching the original einsum batch dimensions.
    with threadpool_limits(limits=2):
        original_projected,_=project(original,384,7);mixed,_=project(raw,384,7)
        np.savez(out/'original_features.npz',raw_pooled=original,projected=original_projected,ids=np.array(ids))
        np.savez(out/'features.npz',raw_pooled=raw,projected=mixed,ids=np.array([r['id'] for r in recipe['records']]))
        validation={};models={};rows=[]
        if a.expected:
            for name,values in [('original_features.npz',original),('features.npz',raw)]:
                expected=np.load(a.expected/name)['raw_pooled']
                np.testing.assert_allclose(values,expected,atol=1e-6,rtol=1e-5)
                validation[name]=dict(max_absolute_error=float(np.max(abs(values-expected))),bitwise_equal=bool(np.array_equal(values,expected)))
        for vi,view in enumerate(VIEWS):
            for method in METHODS:
                w=fit_map(mixed[vi,:,:100],method)
                if w is not None:models[view+'_'+method]=w
                bank=prepare_bank(transform(original_projected[vi,[lookup[i] for i in recipe['reference_ids']]],w))
                cal=transform(original_projected[vi,[lookup[i] for i in recipe['calibration_ids']]],w)
                queries=transform(mixed[vi,:,100:].reshape(-1,7,128),w)
                values=score(bank,np.concatenate([queries,cal]));p=calibrated_p(values[1800:],values[:1800])
                for index,r in enumerate(recipe['records'][100:]*9):
                    rows.append(dict(year=recipe['year'],machine=recipe['machine'],view=view,method=method,
                        condition=index//200,id=r['id'],filename=r['filename'],score=float(values[index]),p_value=float(p[index]),alarm=bool(p[index]<=.04)))
        np.savez(out/'maps.npz',**models)
    with (out/'scores.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    if a.expected:
        with (a.expected/'scores.csv').open(encoding='utf-8',newline='') as f:prior=list(csv.DictReader(f))
        assert len(prior)==len(rows)==14400
        for got,old in zip(rows,prior):
            assert all(str(got[k])==old[k] for k in ['view','method','condition','id','filename','alarm'])
        expected=np.array([float(r['score']) for r in prior]);actual=np.array([r['score'] for r in rows])
        np.testing.assert_allclose(actual,expected,atol=1e-7,rtol=1e-6)
        np.testing.assert_array_equal([r['p_value'] for r in rows],[float(r['p_value']) for r in prior])
        validation['scores']=dict(max_absolute_error=float(np.max(abs(actual-expected))),p_alarm_exact=True)
        expected_maps=np.load(a.expected/'maps.npz')
        for key,value in models.items():np.testing.assert_allclose(value,expected_maps[key],atol=1e-7,rtol=1e-6)
    result=dict(state='passed',dataset=recipe['year']+'/'+recipe['machine'],audio_encodings=3300,waveform_hashes_verified=wave_checks,
        score_rows=len(rows),analytic_maps=6,encoder_training_runs=0,labels_read=False,seconds=time.time()-begin,comparison=validation,
        recipe_SHA256=sha(a.recipe),script_SHA256=sha(Path(__file__)),core_SHA256=sha(Path(__file__).with_name('recovery_core.py')),
        outputs={name:sha(out/name) for name in ['original_features.npz','features.npz','maps.npz','scores.csv']})
    (out/'complete.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');status('complete',3300,3300)
if __name__=='__main__':main()
