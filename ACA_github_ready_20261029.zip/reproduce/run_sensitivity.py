"""Portable per-case pairing/interface sensitivity from fresh or sealed features."""
import argparse,csv,hashlib,json,time
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from recovery_core import fit_map,transform,prepare_bank,score,calibrated_p
OFFSETS=[0,1,7,13,29,43]
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def shifted_map(f,offset):
    if offset==0:return fit_map(f[:,:100],'residual_ridge')
    z=f[:,:60].reshape(-1,f.shape[-2],128);y=np.tile(f[0,np.roll(np.arange(60),-offset)],(9,1,1));maps=[]
    for b in range(f.shape[-2]):
        x=z[:,b].astype(float);target=y[:,b].astype(float);g=x.T@x;lam=float(np.trace(g)/128);assert lam>0
        lhs=g+lam*np.eye(128);rhs=x.T@(target-x);delta=np.linalg.solve(lhs,rhs)
        assert np.linalg.norm(lhs@delta-rhs)/max(np.linalg.norm(rhs),1e-30)<1e-10
        maps.append((np.eye(128)+delta).astype(np.float32))
    return np.stack(maps)
def angular(a,b):
    a=a.astype(float);b=b.astype(float);na=np.linalg.norm(a,axis=-1,keepdims=True);nb=np.linalg.norm(b,axis=-1,keepdims=True)
    assert np.isfinite(a).all() and np.isfinite(b).all() and (na>0).all() and (nb>0).all()
    return float(np.sum((a/na-b/nb)**2,axis=-1).mean())
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--encoder',choices=['BEATs','ECHOv2'],required=True)
    ap.add_argument('--recipe',type=Path,required=True);ap.add_argument('--features',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();recipe=json.loads(a.recipe.read_text(encoding='utf-8'));out=a.output
    if out.exists():raise ValueError('Preserve previous output; choose a new directory')
    mixed=np.load(a.features/'features.npz')['projected'];inputs={'features.npz':sha(a.features/'features.npz')}
    if a.encoder=='BEATs':
        original=np.load(a.features/'original_projected.npy');lookup={i:i for i in range(1200)};views=['BEATs'];inputs['original_projected.npy']=sha(a.features/'original_projected.npy')
        assert mixed.shape==(9,300,8,128) and original.shape==(1200,8,128)
    else:
        loaded=np.load(a.features/'original_features.npz');original=loaded['projected'];ids=[int(i) for i in loaded['ids']];lookup={v:i for i,v in enumerate(ids)};views=['CLS','FM']
        assert ids==[r['id'] for r in recipe['originals']] and mixed.shape==(2,9,300,7,128) and original.shape==(2,900,7,128)
        inputs['original_features.npz']=sha(a.features/'original_features.npz')
    out.mkdir(parents=True);predictions=[];normals=[];maps={};started=time.time()
    with threadpool_limits(limits=2):
        for vi,view in enumerate(views):
            f=mixed if a.encoder=='BEATs' else mixed[vi];o=original if a.encoder=='BEATs' else original[vi];bands=f.shape[-2]
            np.testing.assert_array_equal(f[0],o[[lookup[r['id']] for r in recipe['records']]])
            ref=o[[lookup[i] for i in recipe['reference_ids']]];cal=o[[lookup[i] for i in recipe['calibration_ids']]];original_bank=prepare_bank(ref)
            for offset in OFFSETS:
                w=shifted_map(f,offset);maps[view+'_shift'+str(offset)]=w
                for c in range(9):normals.append(dict(encoder=a.encoder,view=view,year=recipe['year'],machine=recipe['machine'],offset=offset,condition=c,angular_error=angular(transform(f[c,60:100],w),f[0,60:100])))
                q=transform(f[:,100:].reshape(-1,bands,128),w);calq=transform(cal,w)
                for interface in ['joint','original_reference']:
                    bank=prepare_bank(transform(ref,w)) if interface=='joint' else original_bank
                    value=score(bank,np.concatenate([q,calq]));pv=calibrated_p(value[1800:],value[:1800])
                    for j,item in enumerate(recipe['records'][100:]*9):predictions.append(dict(encoder=a.encoder,view=view,year=recipe['year'],machine=recipe['machine'],offset=offset,interface=interface,condition=j//200,filename=item['filename'],score=float(value[j]),p_value=float(pv[j]),alarm=bool(pv[j]<=.04)))
                print(view,'offset',offset,'both interfaces complete',flush=True)
    for name,rr in [('scores.csv',predictions),('normal_angles.csv',normals)]:
        with (out/name).open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
    np.savez(out/'maps.npz',**maps)
    result=dict(state='completed_without_labels',encoder=a.encoder,dataset=recipe['year']+'/'+recipe['machine'],offsets=OFFSETS,
        views=views,score_rows=len(predictions),map_count=len(maps),seconds=time.time()-started,recipe_SHA256=sha(a.recipe),input_SHA256=inputs,
        script_SHA256=sha(Path(__file__)),core_SHA256=sha(Path(__file__).with_name('recovery_core.py')),outputs={n:sha(out/n) for n in ['scores.csv','normal_angles.csv','maps.npz']},independent_offset_or_view_claim=False)
    (out/'complete.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':main()
