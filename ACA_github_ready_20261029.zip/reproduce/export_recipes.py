"""Build label-free portable replay recipes from the sealed E5 artifact tree."""
import csv,hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
OUT=ROOT/'experiments/results/condition_adaptation/evidence_mechanism_20261022/E5_echo_recovery_20261028'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
    plan=read(OUT/'plan.json');complete=read(OUT/'complete.json');seal=read(OUT/'seal.json')
    assert sha(OUT/'seal.json')==complete['score_seal_SHA256']
    ps=read(OUT/'plan_seal.json');assert sha(OUT/'plan.json')==ps['plan_SHA256']
    source=read(ROOT/'experiments/results/strong_improve/echo_source_audit/source_manifest.json')
    shutil.copyfile(HERE.parent/'repro_20261028/recovery_core.py',HERE/'recovery_core.py')
    for qualified,mp in plan['datasets'].items():
        folder=OUT/mp['year']/mp['machine'];local=read(folder/'seal.json')
        for name in ['features.npz','original_features.npz','maps.npz','scores.csv','waveform_identity.csv']:
            assert sha(folder/name)==local[name]==seal['outputs'][(folder/name).relative_to(OUT).as_posix()]
        wave={(int(r['id']),int(r['condition'])):r['waveform_SHA256'] for r in rows(folder/'waveform_identity.csv')}
        old={(int(r['id']),int(r['condition'])):r for r in rows(ROOT/mp['interventions'])}
        assert sha(ROOT/mp['interventions'])==plan['inputs'][mp['interventions']]
        inputs={r['path']:plan['inputs'][r['path']] for r in mp['originals']};records=[]
        for item in mp['records']:
            conditions=[]
            for c in range(9):
                v=old[item['id'],c];n=v['noise_path']
                if n:inputs[n]=plan['inputs'][n]
                conditions.append(dict(noise_path=n,beta=float(v['beta']),waveform_SHA256=wave[item['id'],c]))
            records.append(dict(id=item['id'],filename=item['filename'],path=item['path'],conditions=conditions))
        recipe=dict(year=mp['year'],machine=mp['machine'],originals=mp['originals'],records=records,
            reference_ids=mp['reference_ids'],calibration_ids=mp['calibration_ids'],audio_inputs=inputs,
            checkpoint_SHA256='55fc37964577009c36a5b6e3793fb19541353592dd630b2715ba9ac01df6003c',
            vendor_revision=source['revision'],vendor_files={n:v['sha256'] for n,v in source['files'].items()},
            expected_files={n:local[n] for n in ['original_features.npz','features.npz','maps.npz','scores.csv']},
            source_complete_SHA256=sha(OUT/'complete.json'),source_plan_SHA256=ps['plan_SHA256'],
            labels_embedded=False,historical_researcher_labels_exposed=True)
        dest=HERE/'recipes'/(mp['year']+'_'+mp['machine']+'.json');dest.parent.mkdir(exist_ok=True)
        assert not dest.exists();dest.write_text(json.dumps(recipe,indent=2)+'\n',encoding='utf-8')
    print('17 label-free recipes exported; no audio, weights or ground truth copied')
if __name__=='__main__':main()
