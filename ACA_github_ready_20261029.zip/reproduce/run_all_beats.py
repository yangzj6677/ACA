"""Full standalone E4 audio replay with one verified PCM24 pilot reused by hash."""
import argparse,json,subprocess,sys
from pathlib import Path
from run_echo import sha,read
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data-root',type=Path,required=True);ap.add_argument('--vendor',type=Path,required=True)
    ap.add_argument('--checkpoint',type=Path,required=True);ap.add_argument('--expected-root',type=Path)
    ap.add_argument('--output',type=Path,required=True);ap.add_argument('--reuse-pilot',type=Path)
    a=ap.parse_args();here=Path(__file__).resolve().parent;out=a.output.resolve()
    if out.exists():raise ValueError('Preserve existing replay; use a new output directory')
    out.mkdir(parents=True);completed=[]
    def check(folder,recipe,require_comparison):
        r=read(folder/'complete.json');assert r['state']=='passed' and r['recipe_SHA256']==sha(recipe)
        assert r['script_SHA256']==sha(here/'run_beats.py') and r['core_SHA256']==sha(here/'recovery_core.py')
        assert r['shared_decode_setup_script_SHA256']==sha(here/'run_echo.py')
        assert r['audio_encodings']==3600 and r['score_rows']==7200
        if require_comparison:assert r['comparison']['scores']['p_alarm_exact']
        for n,h in r['outputs'].items():assert sha(folder/n)==h,n
        return r
    for recipe in sorted((here/'beats_recipes').glob('*.json')):
        meta=read(recipe);qualified=meta['year']+'/'+meta['machine'];dest=out/meta['year']/meta['machine']
        reused=qualified=='2025/BandSealer' and a.reuse_pilot is not None
        if reused:dest=a.reuse_pilot.resolve();r=check(dest,recipe,True)
        else:
            dest.parent.mkdir(exist_ok=True,parents=True)
            command=[sys.executable,str(here/'run_beats.py'),'--recipe',str(recipe),'--data-root',str(a.data_root.resolve()),
                '--vendor',str(a.vendor.resolve()),'--checkpoint',str(a.checkpoint.resolve()),'--output',str(dest)]
            if a.expected_root:command+=['--expected',str(a.expected_root.resolve()/meta['year']/meta['machine'])]
            child=subprocess.Popen(command,cwd=here)
            (out/'status.json').write_text(json.dumps(dict(stage='running',dataset=qualified,child_pid=child.pid,completed=len(completed)))+'\n')
            rc=child.wait()
            if rc:
                (out/'failure.json').write_text(json.dumps(dict(dataset=qualified,exit_code=rc,preserve_partial_output=True))+'\n')
                raise RuntimeError('BEATs replay failed; preserve partial output: '+qualified)
            r=check(dest,recipe,bool(a.expected_root))
        completed.append(dict(dataset=qualified,result_directory=str(dest),complete_SHA256=sha(dest/'complete.json'),audio_encodings=r['audio_encodings'],reused=bool(reused),reference_comparison=bool(r.get('comparison',{}).get('scores',{}).get('p_alarm_exact',False))))
        (out/'completed_cases.json').write_text(json.dumps(completed,indent=2)+'\n')
        print('ALL-BEATS-REPLAY completed',qualified,len(completed),'/17',flush=True)
    assert len(completed)==17
    total=sum(c['audio_encodings'] for c in completed);reused=sum(c['audio_encodings'] for c in completed if c['reused'])
    all_verified=all(c['reference_comparison'] for c in completed)
    (out/'complete.json').write_text(json.dumps(dict(state='all_17_standalone_BEATs_audio_replays_verified' if all_verified else 'all_17_BEATs_audio_cases_generated_without_full_reference_comparison',cases=completed,
        main_audio_encodings=total,reused_pilot_encodings=reused,new_encodings_this_batch=total-reused,score_rows=122400,
        script_SHA256=sha(here/'run_beats.py'),batch_script_SHA256=sha(Path(__file__)),labels_read=False),indent=2)+'\n')
    (out/'status.json').write_text(json.dumps(dict(stage='complete',completed=17))+'\n')
if __name__=='__main__':main()
