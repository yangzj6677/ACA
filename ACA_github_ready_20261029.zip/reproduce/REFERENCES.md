# Primary sources and provenance

- BEATs architecture: [Chen et al., BEATs: Audio Pre-Training with Acoustic Tokenizers](https://arxiv.org/abs/2212.09058).
- Actual BEATs-family checkpoint used in E4: public mirror `lpepino/beats_ckpts`, revision `5b53b0404df452a3a607d7e67687227730e5bad1`, file `BEATs_iter3.pt`, SHA256 `8d1b234032a9ccff353612dc6c20982346dc2968b205b79d97303eb5e77bfb34`. Byte equivalence to the upstream OneDrive release has not been independently verified; the upstream link was not accessible during this audit. Do not silently relabel it as a verified original release.
- ECHOv2 architecture: [Zhang, Liu and Li, ECHOv2](https://arxiv.org/abs/2607.10596v2). The model card contains a citation to the earlier ECHO paper; the ECHOv2 title and version are taken from the actual arXiv record.
- ECHOv2 weights: [author model repository](https://huggingface.co/yucongzh/echo-small-v2/tree/234c2cc250225a1915f8bad964bb6f3aa7d5109f), SHA256 `55fc37964577009c36a5b6e3793fb19541353592dd630b2715ba9ac01df6003c`.
- Scoring prior: [Saengthong and Shinozaki, Sub-Band Spectral Matching with Localized Score Aggregation for Robust Anomalous Sound Detection](https://arxiv.org/abs/2603.13749).
- Relevant mixture objective: [Saengthong et al., Retaining Mixture Representations for Domain Generalized Anomalous Sound Detection](https://arxiv.org/abs/2510.25182).
- Relevant two-channel recovery objective: [Fujimura et al., Anomalous Sound Detection Meets Noise-Aware Self-Supervised Learning](https://arxiv.org/abs/2608.00447v2). Single-channel experiments do not constitute a faithful full NA-SSL comparison.
- Official evaluator sources: [DCASE2024](https://github.com/nttcslab/dcase2024_task2_evaluator/tree/b5d17f63769bf4372a5412a7ede1f814c9590047), [DCASE2025](https://github.com/nttcslab/dcase2025_task2_evaluator/tree/f903124a40a4cdb3faf2b2d6fa69c6a9f1794192).

The local scripts implement controlled normal-only analytic adaptation. Standard ridge, covariance and PSD metric identities are not claimed as novel algorithms.
