"""Portable NumPy ROC/metric replay with pinned public truth-file hashes."""
import argparse,csv,hashlib,json
from pathlib import Path
import numpy as np

REVISIONS={'2024':'b5d17f63769bf4372a5412a7ede1f814c9590047','2025':'f903124a40a4cdb3faf2b2d6fa69c6a9f1794192'}
def csvrows(path,dictionaries=False):
    with path.open(encoding='utf-8-sig',newline='') as stream:return list(csv.DictReader(stream) if dictionaries else csv.reader(stream))
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def roc_points(y,s):
    y=np.asarray(y,dtype=np.int64);s=np.asarray(s,dtype=np.float64)
    if len(y)!=len(s) or set(y)!={0,1} or not np.isfinite(s).all():raise ValueError('Invalid ROC data')
    order=np.argsort(s,kind='stable')[::-1];labels=y[order];values=s[order]
    ends=np.flatnonzero(np.r_[values[1:]!=values[:-1],True]);positive=np.cumsum(labels)
    tp=np.r_[0,positive[ends]].astype(np.int64);fp=np.r_[0,ends+1-positive[ends]].astype(np.int64)
    return fp,tp,int(np.sum(y==0)),int(np.sum(y==1))

def auc(y,s,max_fpr=None):
    fp,tp,n,p=roc_points(y,s);fpr=fp/n;tpr=tp/p
    if max_fpr is None:return float(np.trapz(tpr,fpr))
    cut=np.searchsorted(fpr,max_fpr,side='right')
    ff=np.r_[fpr[:cut],max_fpr];tt=np.r_[tpr[:cut],np.interp(max_fpr,fpr[cut-1:cut+1],tpr[cut-1:cut+1])]
    area=float(np.trapz(tt,ff));chance=.5*max_fpr**2
    return float(.5*(1+(area-chance)/(max_fpr-chance)))

def metrics(y,d,s,alarm):
    source=(d==0)|(y==1);target=(d==1)|(y==1)
    a=auc(y[source],s[source]);b=auc(y[target],s[target]);pauc=auc(y,s,.1)
    normal=int(np.sum(y==0));anomaly=int(np.sum(y==1));fp=int(np.sum((y==0)&alarm));fn=int(np.sum((y==1)&~alarm))
    value=dict(auc_source=a,auc_target=b,pauc=pauc,hmean=0. if min(a,b,pauc)==0 else float(3/(1/a+1/b+1/pauc)),
        auc_all=auc(y,s),FP=fp,FN=fn,normal=normal,anomaly=anomaly,FPR=fp/normal,FNR=fn/anomaly)
    for name,domain in [('source',0),('target',1)]:
        nn=(d==domain)&(y==0);aa=(d==domain)&(y==1)
        value[name+'_FPR']=float(np.sum(nn&alarm)/np.sum(nn));value[name+'_FNR']=float(np.sum(aa&~alarm)/np.sum(aa))
    f,t,n,p=roc_points(y,s);budget=int(np.floor(.1*n));eligible=f<=budget;tp=int(np.max(t[eligible]));fp=int(np.min(f[eligible&(t==tp)]))
    value.update(oracle_TPR_at_FPR10=tp/p,oracle_achieved_FPR=fp/n,oracle_FP_budget=budget)
    return value

def truth(folder,provenance,year,machine,names):
    if provenance['revision']!=REVISIONS[year]:raise ValueError('Unpinned truth revision')
    expected={(r['machine'],r['kind']):r['sha256'] for r in provenance['files']};raw={}
    for kind in ['ground_truth_data','ground_truth_domain','ground_truth_attributes']:
        p=folder/kind/('ground_truth_'+machine+'_section_00_test.csv')
        if sha(p)!=expected[machine,kind]:raise ValueError('Truth bytes mismatch: '+str(p))
        raw[kind]=csvrows(p)
        if len(raw[kind])!=200 or any(len(r)<2 for r in raw[kind]):raise ValueError('Invalid truth schema')
    labels={Path(r[0]).name:int(r[1]) for r in raw['ground_truth_data']};domains={Path(r[0]).name:int(r[1]) for r in raw['ground_truth_domain']}
    if set(labels)!=set(names):
        mapping={Path(r[1] if r[1].endswith('.wav') else r[1]+'.wav').name:Path(r[0]).name for r in raw['ground_truth_attributes']}
        if set(mapping)!=set(names) or set(mapping.values())!=set(labels):raise ValueError('Non-bijective official ID mapping')
        labels={n:labels[mapping[n]] for n in names};domains={n:domains[mapping[n]] for n in names}
    if set(labels)!=set(domains) or set(labels)!=set(names):raise ValueError('Truth names disagree')
    y=np.array([labels[n] for n in names]);d=np.array([domains[n] for n in names])
    if any(np.sum((y==a)&(d==b))!=50 for a in [0,1] for b in [0,1]):raise ValueError('Unexpected state/domain counts')
    return y,d

def main():
    p=argparse.ArgumentParser();p.add_argument('--scores',type=Path,required=True);p.add_argument('--expected-metrics',type=Path,required=True)
    p.add_argument('--truth-2024',type=Path,required=True);p.add_argument('--truth-2025',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args();here=Path(__file__).resolve().parent
    provenance={year:json.loads((here/('truth_provenance_'+year+'.json')).read_text(encoding='utf-8')) for year in REVISIONS}
    expected=csvrows(args.expected_metrics,True);prior={(r['year'],r['machine'],r.get('view',''),r['method'],int(r['condition'])):r for r in expected}
    grouped={}
    for r in csvrows(args.scores,True):
        key=(r['year'],r['machine'],r.get('view',''),r['method'],int(r['condition']));grouped.setdefault(key,[]).append(r)
    if set(grouped)!=set(prior):raise ValueError('Missing/extra method or condition')
    truth_cache={};worst=0.;replayed=0
    for key,rows in grouped.items():
        year,machine,view,method,condition=key;names=[r['filename'] for r in rows]
        if len(names)!=200 or len(set(names))!=200:raise ValueError('Incomplete test cases')
        if (year,machine) not in truth_cache:truth_cache[year,machine]=truth(getattr(args,'truth_'+year),provenance[year],year,machine,names),names
        (y,d),oldnames=truth_cache[year,machine]
        if names!=oldnames:raise ValueError('Query order changed between methods')
        scores=np.array([float(r['score']) for r in rows]);pv=np.array([float(r['p_value']) for r in rows]);alarm=np.array([r['alarm'].lower()=='true' for r in rows])
        np.testing.assert_array_equal(alarm,pv<=.04)
        values=metrics(y,d,scores,alarm)
        for name,value in values.items():
            error=abs(float(prior[key][name])-value);worst=max(worst,error)
            if error>1e-12:raise ValueError('Metric disagreement: '+str((key,name,error)))
        replayed+=len(rows)
    result=dict(state='passed',prediction_rows=replayed,metric_rows=len(grouped),datasets=len(truth_cache),max_metric_error=worst,
        ROC_implementation='standalone NumPy tie-aware curve and McClish pAUC',oracle_threshold_is_diagnostic_only=True,
        source_score_SHA256=sha(args.scores),expected_metrics_SHA256=sha(args.expected_metrics))
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
