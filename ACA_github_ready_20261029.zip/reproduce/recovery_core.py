"""Portable normal-recovery math. No workspace imports, network, labels or Torch."""
from dataclasses import dataclass
import numpy as np
from scipy.spatial.distance import cdist

@dataclass
class ReferenceBank:
    vectors: np.ndarray
    rho: np.ndarray

def project(features, raw_dimension, bands, seed=20261008, dimension=128):
    if features.shape[-2:] != (bands,raw_dimension) or not 0 < dimension <= raw_dimension:
        raise ValueError('Projection dimensions do not match features')
    matrices=np.stack([np.linalg.qr(np.random.RandomState(seed+b).normal(size=(raw_dimension,dimension)))[0].astype(np.float32) for b in range(bands)])
    return np.einsum('...bd,bdk->...bk',features,matrices).astype(np.float32),matrices

def fit_map(normal_views,method,fit_count=60):
    """normal_views: conditions x records x bands x dimension; condition 0 is target."""
    if method=='identity':return None
    if method not in {'residual_ridge','covariance_only','shuffled_target'}:raise ValueError(method)
    a=np.asarray(normal_views)
    if a.ndim!=4 or a.shape[1]<fit_count or not np.isfinite(a).all():raise ValueError('Invalid normal features')
    conditions,_,bands,dimension=a.shape
    z=a[:,:fit_count].reshape(-1,bands,dimension)
    ids=np.roll(np.arange(fit_count),-1) if method=='shuffled_target' else np.arange(fit_count)
    y=np.tile(a[0,ids],(conditions,1,1));maps=[]
    for b in range(bands):
        x=z[:,b].astype(np.float64);target=y[:,b].astype(np.float64);gram=x.T@x
        lam=float(np.trace(gram)/dimension)
        if not lam>0:raise ValueError('Zero fit energy')
        lhs=gram+lam*np.eye(dimension)
        if method=='covariance_only':
            value,vector=np.linalg.eigh(lhs)
            if np.any(value<=0):raise ValueError('Non-positive covariance system')
            w=(vector*(np.sqrt(lam)/np.sqrt(value))[None,:])@vector.T
        else:w=np.eye(dimension)+np.linalg.solve(lhs,x.T@(target-x))
        maps.append(w.astype(np.float32))
    return np.stack(maps)

def transform(features,mapping):
    if mapping is None:return np.asarray(features,dtype=np.float32)
    return np.einsum('...bd,bdk->...bk',np.asarray(features,dtype=np.float64),np.asarray(mapping,dtype=np.float64)).astype(np.float32)

def prepare_bank(vectors):
    x=np.asarray(vectors,dtype=np.float32)
    if x.ndim!=3 or len(x)<2 or not np.isfinite(x).all():raise ValueError('Invalid reference bank')
    scales=[]
    for b in range(x.shape[1]):
        z=x[:,b].astype(np.float64);within=np.clip(cdist(z,z,'cosine'),0,2)/2
        np.fill_diagonal(within,np.inf)
        scale=np.maximum(within.min(1),1e-6).astype(np.float32)
        if not np.isfinite(scale).all():raise ValueError('Invalid reference cosine/scale')
        scales.append(scale)
    return ReferenceBank(x,np.stack(scales,axis=1))

def score(bank,queries):
    q=np.asarray(queries,dtype=np.float32);x=bank.vectors;bands=x.shape[1]
    if q.ndim!=3 or q.shape[1:]!=x.shape[1:] or not np.isfinite(q).all():raise ValueError('Invalid queries')
    values=np.zeros(len(q),dtype=np.float64)
    for b in range(bands):
        dist=np.clip(cdist(q[:,b].astype(np.float64),x[:,b].astype(np.float64),'cosine'),0,2)/2
        values+=(dist/bank.rho[:,b].astype(np.float64)[None,:]).min(1)/bands
    if not np.isfinite(values).all():raise ValueError('Non-finite score')
    return values

def calibrated_p(calibration,scores):
    cal=np.asarray(calibration,dtype=np.float64);q=np.asarray(scores,dtype=np.float64)
    if cal.ndim!=1 or len(cal)==0 or not np.isfinite(cal).all() or not np.isfinite(q).all():raise ValueError('Invalid calibration scores')
    count=len(cal)-np.searchsorted(np.sort(cal),q,side='left')
    return (1.0+count)/(len(cal)+1.0)
