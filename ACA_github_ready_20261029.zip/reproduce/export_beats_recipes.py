"""Export exact BEATs batch-eight replay inputs without bundling audio/weights."""
import csv,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
BASE=ROOT/'experiments/results/condition_adaptation/evidence_mechanism_20261022';E4=BASE/'E4_external_recovery_20261027_attempt02'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    plan=read(E4/'plan.json');ps=read(E4/'plan_seal.json');assert sha(E4/'plan.json')==ps['plan_SHA256']
    with (E4/'audio_audit.csv').open(encoding='utf-8',newline='') as f:audits={(r['year'],r['machine'],int(r['id'])):r for r in csv.DictReader(f)}
    assert sha(E4/'audio_audit.csv')==ps['inputs'][(E4/'audio_audit.csv').relative_to(ROOT).as_posix()]
    vendor=ROOT/'experiments/vendor/GenRepASD';code={p.relative_to(vendor).as_posix():sha(p) for p in (vendor/'beats').glob('*.py')}
    revision=subprocess.check_output(['git','-C',str(vendor),'rev-parse','HEAD'],text=True).strip()
    for _,mp in plan['datasets'].items():
        path=HERE/'recipes'/(mp['year']+'_'+mp['machine']+'.json');recipe=read(path)
        original=[]
        for i in range(1200):
            r=audits[mp['year'],mp['machine'],i];original.append(dict(id=i,path=r['path'],filename=Path(r['path']).name));recipe['audio_inputs'][r['path']]=r['file_SHA256']
        folder=E4/mp['year']/mp['machine'];local=read(folder/'seal.json')
        recipe.update(originals=original,checkpoint_SHA256='8d1b234032a9ccff353612dc6c20982346dc2968b205b79d97303eb5e77bfb34',
            checkpoint_official_equivalence_verified=False,vendor_revision=revision,vendor_files=code,
            expected_files={n:local[n] for n in ['features.npz','original_projected.npy','maps.npz','scores.csv']},source_complete_SHA256=sha(E4/'complete.json'),source_plan_SHA256=ps['plan_SHA256'])
        dest=HERE/'beats_recipes'/path.name;dest.parent.mkdir(exist_ok=True);assert not dest.exists()
        dest.write_text(json.dumps(recipe,indent=2)+'\n',encoding='utf-8')
    print('17 BEATs batch-eight recipes exported')
if __name__=='__main__':main()
