# E5 standalone audio replay candidate

This directory contains a label-free audio-to-score entry point and 17 fixed recipes.
It imports no modules from the original experiment workspace. The only nonstandard local source it imports is the separately supplied official ECHOv2 vendor tree, verified against the recipe's hashes.

Provide the original WAVs in the relative `experiments/data/...` hierarchy below a chosen data root, official ECHOv2 code at revision `b2fb58549f343dfcf6271a600e1280945d647334`, and the pinned official checkpoint. No automatic downloads occur. The code checks all selected audio and vendor hashes before encoding.

The examples below assume the working directory is `reproduce/`.

```powershell
python run_echo.py --recipe recipes/2024_3DPrinter.json --data-root DATA_ROOT --vendor ECHO_SOURCE --checkpoint MODEL_SAFETENSORS --output NEW_OUTPUT_DIRECTORY --expected SEALED_E5_CASE_DIRECTORY
```

Omit `--expected` to produce results without loading the old features or scores. It is used only for comparisons after encoding/fitting/scoring, never to compute new outputs. Each case executes 900 original plus 2400 mixed audio encodings, fits six maps across the two fixed views, and produces 14400 scores. `--device cpu` is supported but has not been timed or verified as a complete rerun. Use a fresh output directory for each attempt; partial results are preserved and not resumed automatically.

The full 17-case CUDA replay has completed. It reproduced all original and mixed raw features bitwise across 56100 encodings, refit all 102 maps, and reproduced all p values and alarms over 244800 scores exactly. Maximum absolute score difference is 1.17e-8, within the fixed score tolerances. The first 2024/3DPrinter pilot is reused by hash rather than encoded twice; it accounts for 3300 encodings, with 52800 new encodings in the remaining batch. Evidence is summarized in [E5 full audio replay summary](../validation_evidence/E5_full_audio_replay_summary_20261028.json); original case records are retained in the pilot and full batch output directories. This is a complete execution replay of the same data, not a new independent cohort.

Validated environment: Python 3.12.11, NumPy 1.26.4, SciPy 1.13.1, PyTorch/torchaudio 2.7.1 with CUDA 12.8, safetensors, einops and threadpoolctl. Exact local versions are recorded in the environment audit. Different GPU hardware may introduce floating-point differences; no cross-hardware bitwise guarantee is made. The audio-to-score scripts do not use labels; use the separately supplied metric replay after scores are complete.

This is an internal release candidate, not a public release. Audio, weights and third-party code are not bundled. The project-owned Python code uses MIT; the selected derived-data license and source-rights review are described in [LICENSES.md](../LICENSES.md). The recipe exporter is a maintainer tool needing the original sealed artifacts; ordinary replay uses only `run_echo.py`, `recovery_core.py`, a recipe and the explicitly supplied external assets.

## Batch production versus reference validation

`run_all.py` and `run_all_beats.py` run the 17 fixed cases with the same `--data-root`, `--vendor`, `--checkpoint` and fresh `--output` arguments as the single-case runners. `--expected-root` is optional. Without it, the batch produces results and verifies input/output hashes but cannot compare against the historical feature and score files; the batch completion state explicitly says that full reference comparison was not performed. With `--expected-root`, each case is compared to the separately supplied historical files and the batch can report verified status only if all comparisons pass. The expected feature files are not bundled.

`--reuse-pilot` is optional and accepts only a previously verified pilot with matching recipe, source-script and output hashes. Batch accounting separately reports actually reused and newly encoded audio. Historical validation evidence below records the original scripts and run; it is not a new end-to-end validation of modified batch wrappers.

## Separate BEATs entry point

`run_beats.py` and `beats_recipes` preserve E4's batch-eight BF16 interface. They encode all 1200 original records in their historical batch groups plus 2400 mixed views, for 3600 encodings and 7200 scores per case. They reuse only the standalone decoder/setup helpers and portable CPU core, not original experiment modules. The 2025/BandSealer PCM24 pilot passed: raw mixed/original selected features and all original projections are bitwise identical, p/alarms are exact, and maximum score error is 5.01e-14. The full seventeen-case BEATs audio replay also passed: 61200 encodings, 51 maps, 122400 scores, bitwise raw features and original projections, exact p/alarms, and maximum score error 2.73e-13. The PCM24 pilot was reused by hash; the remaining batch encoded 57600 inputs. Evidence is in [E4 full audio replay summary](../validation_evidence/E4_full_audio_replay_summary_20261028.json). The BEATs checkpoint remains a byte-pinned public-mirror asset with upstream official equivalence unverified.

## Pairing and reference sensitivity from regenerated features

```powershell
python run_sensitivity.py --encoder ECHOv2 --recipe recipes/2024_3DPrinter.json --features NEW_AUDIO_REPLAY_CASE --output NEW_SENSITIVITY_DIRECTORY
python evaluate_sensitivity.py --results NEW_SENSITIVITY_DIRECTORY --truth PINNED_2024_EVALUATOR --output NEW_EVALUATION_DIRECTORY
```

For BEATs, select `--encoder BEATs` and the corresponding file under `beats_recipes`. The feature directory is the output of `run_echo.py` or `run_beats.py`, so the sensitivity analysis does not require the original experiment modules or binary-identical NPZ archives. It checks feature/identity alignment, refits correct pairing (offset 0) and all five fixed cycles (1, 7, 13, 29, 43), and scores both the mapped and original reference interfaces. The evaluator verifies the producer's file hashes before reading separately supplied, pinned official labels.

The two full-case validation examples cover BEATs/2025 BandSealer and ECHOv2/2024 3DPrinter, including both ECHO views. Together, all 64800 scores, 324 metric rows, p values and alarms match the sealed scientific results. Maximum score differences are 4.80e-14 and 2.80e-12; maximum metric error is 2.23e-16. This validates the independent pipeline on two complete cases; the original scientific E8 experiment itself covers all 17 cases. Do not describe this separate sensitivity validation as a second full seventeen-case run.

Five designed offsets share the same recordings and are not independent statistical samples. Use the original and sensitivity results together; do not choose a winning offset, interface, or ECHO view from the evaluation labels.

The pilot has now been extended to the full fixed cohort for each encoder. All 34 encoder cases pass independent score/metric/contrast comparison: 1,101,600 scores, 5,508 metric rows, 2,754 angular errors and 510 machine-level contrasts. Correct pairing (offset 0), all five fixed controls and both reference interfaces are included. Maximum score error is 1.1630520324601434e-8, maximum metric error 3.3306690738754696e-16; angular errors, p values, alarms and all counterexample classifications match exactly. Evidence is in [full portable sensitivity validation](../validation_evidence/full_portable_sensitivity_validation_20261028.json). All score production was sealed before evaluation. These are execution replays from previously regenerated features, with no new audio encodings or independent cohort.
